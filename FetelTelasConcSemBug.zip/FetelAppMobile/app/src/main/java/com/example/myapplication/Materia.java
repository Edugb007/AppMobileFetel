package com.example.myapplication;

import java.util.List;

public class Materia {

    private String nome;
    private String icone;        // emoji representando a matéria
    private int cor;             // cor em int (Color.parseColor)
    private List<Apostila> apostilas;

    public Materia(String nome, String icone, int cor, List<Apostila> apostilas) {
        this.nome      = nome;
        this.icone     = icone;
        this.cor       = cor;
        this.apostilas = apostilas;
    }

    public String getNome()              { return nome; }
    public String getIcone()             { return icone; }
    public int getCor()                  { return cor; }
    public List<Apostila> getApostilas() { return apostilas; }
}
