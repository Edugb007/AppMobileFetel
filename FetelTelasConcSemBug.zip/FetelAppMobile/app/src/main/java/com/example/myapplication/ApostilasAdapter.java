package com.example.myapplication;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ApostilasAdapter extends RecyclerView.Adapter<ApostilasAdapter.ViewHolder> {

    public interface OnApostilaClick {
        void onClick(Apostila apostila);
    }

    Context context;
    List<Apostila> lista;
    int cor;
    OnApostilaClick listener;

    public ApostilasAdapter(Context context, List<Apostila> lista, int cor, OnApostilaClick listener) {
        this.context  = context;
        this.lista    = lista;
        this.cor      = cor;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_apostila, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Apostila apostila = lista.get(position);

        holder.txtTitulo.setText(apostila.getTitulo());
        holder.txtDescricao.setText(apostila.getDescricao());

        // Ícone de PDF colorido com a cor da matéria
        holder.viewIconeCor.setBackgroundTintList(ColorStateList.valueOf(cor));

        holder.itemView.setOnClickListener(v -> listener.onClick(apostila));
    }

    @Override
    public int getItemCount() { return lista.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitulo, txtDescricao;
        View viewIconeCor;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitulo   = itemView.findViewById(R.id.txtTituloApostila);
            txtDescricao = itemView.findViewById(R.id.txtDescricaoApostila);
            viewIconeCor = itemView.findViewById(R.id.viewCorApostila);
        }
    }
}
