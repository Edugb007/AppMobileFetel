package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class TelaLogin extends AppCompatActivity {

    EditText txtEmail, txtSenha;
    AppCompatButton btnLogar;
    TextView txtRecupSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        txtEmail      = findViewById(R.id.txtEmail);
        txtSenha      = findViewById(R.id.txtSenha);
        btnLogar      = findViewById(R.id.btnLogar);
        txtRecupSenha = findViewById(R.id.txtRecupSenha);

        btnLogar.setOnClickListener(v -> tentarLogin());

        txtRecupSenha.setOnClickListener(v -> {
            startActivity(new Intent(TelaLogin.this, FormRecupSenha.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void tentarLogin() {
        String email = txtEmail.getText().toString().trim();
        String senha = txtSenha.getText().toString().trim();

        // Resetar bordas
        txtEmail.setBackground(getDrawable(R.drawable.bg_input));
        txtSenha.setBackground(getDrawable(R.drawable.bg_input));

        if (TextUtils.isEmpty(email)) {
            txtEmail.setBackground(getDrawable(R.drawable.bg_input_erro));
            txtEmail.setError("Preencha o e-mail");
            txtEmail.requestFocus();
            shakeView(txtEmail);
            return;
        }

        if (TextUtils.isEmpty(senha)) {
            txtSenha.setBackground(getDrawable(R.drawable.bg_input_erro));
            txtSenha.setError("Preencha a senha");
            txtSenha.requestFocus();
            shakeView(txtSenha);
            return;
        }

        irParaHome();
    }

    private void irParaHome() {
        // Pequeno feedback no botão antes de navegar
        btnLogar.animate()
                .scaleX(0.96f).scaleY(0.96f)
                .setDuration(100)
                .withEndAction(() -> {
                    btnLogar.animate().scaleX(1f).scaleY(1f).setDuration(100).start();

                    Intent intent = new Intent(TelaLogin.this, TelaHome.class);
                    // Limpa a pilha — não volta pro login com o botão de voltar
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                })
                .start();
    }

    // Shake horizontal para campos com erro
    private void shakeView(View view) {
        view.animate().translationX(12f).setDuration(60)
            .withEndAction(() ->
                view.animate().translationX(-12f).setDuration(60)
                .withEndAction(() ->
                    view.animate().translationX(8f).setDuration(50)
                    .withEndAction(() ->
                        view.animate().translationX(0f).setDuration(50).start()
                    ).start()
                ).start()
            ).start();
    }

    // Não volta para a splash — fecha o app
    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
