package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class ContatoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contato);

        // ── Voltar ─────────────────────────────────────
        findViewById(R.id.btnVoltarContato).setOnClickListener(v -> finish());

        // ── Telefone (discador) ─────────────────────────
        // TODO: substituir pelo telefone real da escola
        String telefone = "+55 11 9999-9999";
        findViewById(R.id.itemTelefone).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL,
                    Uri.parse("tel:" + telefone.replaceAll("[^+\\d]", "")));
            startActivity(intent);
        });

        // ── E-mail ─────────────────────────────────────
        // TODO: substituir pelo e-mail real da escola
        String email = "secretaria@etec-fetel.sp.gov.br";
        findViewById(R.id.itemEmail).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO,
                    Uri.parse("mailto:" + email));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Contato via App FETEL");
            startActivity(Intent.createChooser(intent, "Enviar e-mail"));
        });

        // ── Endereço → Google Maps ──────────────────────
        // TODO: substituir pelo endereço real da escola
        String endereco = "Av. Exemplo, 1234, São Paulo, SP";
        findViewById(R.id.itemEndereco).setOnClickListener(v -> {
            Uri geoUri = Uri.parse("geo:0,0?q=" + Uri.encode(endereco));
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, geoUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                Uri browserUri = Uri.parse(
                        "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(endereco));
                startActivity(new Intent(Intent.ACTION_VIEW, browserUri));
            }
        });
    }
}
