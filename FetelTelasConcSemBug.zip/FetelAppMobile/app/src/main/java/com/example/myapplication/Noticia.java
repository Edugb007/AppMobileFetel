package com.example.myapplication;

public class Noticia {

    String titulo;
    String resumo;
    String descricao;
    String data;
    String categoria;
    int imagem;

    public Noticia(String titulo, String resumo, String descricao,
                   String data, String categoria, int imagem) {
        this.titulo    = titulo;
        this.resumo    = resumo;
        this.descricao = descricao;
        this.data      = data;
        this.categoria = categoria;
        this.imagem    = imagem;
    }

    public String getTitulo()    { return titulo; }
    public String getResumo()    { return resumo; }
    public String getDescricao() { return descricao; }
    public String getData()      { return data; }
    public String getCategoria() { return categoria; }
    public int    getImagem()    { return imagem; }
}
