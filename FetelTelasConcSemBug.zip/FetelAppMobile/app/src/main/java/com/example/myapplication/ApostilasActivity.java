package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ApostilasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apostilas);

        // Recebe dados da matéria
        String nome   = getIntent().getStringExtra("materia_nome");
        String icone  = getIntent().getStringExtra("materia_icone");
        int    cor    = getIntent().getIntExtra("materia_cor", 0xFF051233);

        String[] titulos    = getIntent().getStringArrayExtra("apostilas_titulos");
        String[] descricoes = getIntent().getStringArrayExtra("apostilas_descricoes");
        String[] arquivos   = getIntent().getStringArrayExtra("apostilas_arquivos");

        // Header
        TextView txtTitulo = findViewById(R.id.txtTituloApostilas);
        TextView txtIcone  = findViewById(R.id.txtIconeApostilas);
        txtTitulo.setText(nome);
        txtIcone.setText(icone);

        // Cor da barra do header
        findViewById(R.id.headerApostilas).setBackgroundColor(cor);

        // Botão voltar
        ImageButton btnVoltar = findViewById(R.id.btnVoltarApostilas);
        btnVoltar.setOnClickListener(v -> {
            finish();
        });

        // Monta lista de apostilas
        List<Apostila> apostilas = new ArrayList<>();
        if (titulos != null) {
            for (int i = 0; i < titulos.length; i++) {
                apostilas.add(new Apostila(titulos[i], descricoes[i], arquivos[i]));
            }
        }

        RecyclerView recycler = findViewById(R.id.recyclerApostilas);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        ApostilasAdapter adapter = new ApostilasAdapter(this, apostilas, cor, apostila -> {
            Intent intent = new Intent(this, PdfViewerActivity.class);
            intent.putExtra("pdf_arquivo", apostila.getNomeArquivo());
            intent.putExtra("pdf_titulo",  apostila.getTitulo());
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        recycler.setAdapter(adapter);
    }
}
