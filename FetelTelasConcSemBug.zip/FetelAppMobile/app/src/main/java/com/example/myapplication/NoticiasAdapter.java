package com.example.myapplication;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoticiasAdapter extends RecyclerView.Adapter<NoticiasAdapter.ViewHolder> {

    Context context;
    List<Noticia> listaNoticias;

    public NoticiasAdapter(Context context, List<Noticia> listaNoticias) {
        this.context = context;
        this.listaNoticias = listaNoticias;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_noticia, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Noticia noticia = listaNoticias.get(position);

        holder.titulo.setText(noticia.getTitulo());
        holder.resumo.setText(noticia.getResumo());
        holder.data.setText(noticia.getData());
        holder.imagem.setImageResource(noticia.getImagem());
        holder.categoria.setText(noticia.getCategoria());

        // Clique no card inteiro
        holder.itemView.setOnClickListener(v -> abrirDialog(noticia));

        // Clique no botão "Ler mais"
        holder.btnLerMais.setOnClickListener(v -> abrirDialog(noticia));
    }

    private void abrirDialog(Noticia noticia) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_noticia);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (context.getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageView  dialogImagem    = dialog.findViewById(R.id.dialogImagem);
        TextView   dialogTitulo    = dialog.findViewById(R.id.dialogTitulo);
        TextView   dialogData      = dialog.findViewById(R.id.dialogData);
        TextView   dialogDescricao = dialog.findViewById(R.id.dialogDescricao);
        TextView   dialogCategoria = dialog.findViewById(R.id.dialogCategoria);
        ImageButton btnFechar      = dialog.findViewById(R.id.btnFecharDialog);

        dialogImagem.setImageResource(noticia.getImagem());
        dialogTitulo.setText(noticia.getTitulo());
        dialogData.setText(noticia.getData());
        dialogDescricao.setText(noticia.getDescricao());
        dialogCategoria.setText(noticia.getCategoria());

        btnFechar.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    @Override
    public int getItemCount() {
        return listaNoticias.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView  titulo, resumo, data, categoria, btnLerMais;
        ImageView imagem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo     = itemView.findViewById(R.id.txtTitulo);
            resumo     = itemView.findViewById(R.id.txtResumo);
            data       = itemView.findViewById(R.id.txtData);
            imagem     = itemView.findViewById(R.id.imgNoticia);
            categoria  = itemView.findViewById(R.id.txtCategoria);
            btnLerMais = itemView.findViewById(R.id.txtLerMais);
        }
    }
}
