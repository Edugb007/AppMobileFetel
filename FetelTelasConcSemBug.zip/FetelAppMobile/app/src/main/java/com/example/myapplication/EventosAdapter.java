package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventosAdapter extends RecyclerView.Adapter<EventosAdapter.ViewHolder> {

    Context context;
    List<Evento> listaEventos;

    public EventosAdapter(Context context, List<Evento> listaEventos) {
        this.context = context;
        this.listaEventos = listaEventos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_evento, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Evento evento = listaEventos.get(position);

        holder.txtDia.setText(String.valueOf(evento.getDia()));
        holder.txtMes.setText(evento.getMes());
        holder.txtTitulo.setText(evento.getTitulo());
        holder.txtDescricao.setText(evento.getDescricao());
        holder.txtCategoria.setText(evento.getCategoria());

        // Cor da bolinha lateral
        holder.viewCor.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(evento.getCorCategoria())
        );
    }

    @Override
    public int getItemCount() {
        return listaEventos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtDia, txtMes, txtTitulo, txtDescricao, txtCategoria;
        View viewCor;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDia       = itemView.findViewById(R.id.txtDiaEvento);
            txtMes       = itemView.findViewById(R.id.txtMesEvento);
            txtTitulo    = itemView.findViewById(R.id.txtTituloEvento);
            txtDescricao = itemView.findViewById(R.id.txtDescricaoEvento);
            txtCategoria = itemView.findViewById(R.id.txtCategoriaEvento);
            viewCor      = itemView.findViewById(R.id.viewCategoriaCor);
        }
    }
}
