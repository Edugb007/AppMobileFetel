package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper; // Adicionado para melhor performance

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView; // Importação do Lottie

public class TelaCarregamento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_carregamento);

        //2.5s de duração
        new Handler(Looper.getMainLooper()).postDelayed(this::irParaLogin, 2500);
    }

    private void irParaLogin() {
        Intent intent = new Intent(TelaCarregamento.this, TelaLogin.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_login_enter, R.anim.slide_login_exit);
        finish();
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        finishAffinity();
    }
}