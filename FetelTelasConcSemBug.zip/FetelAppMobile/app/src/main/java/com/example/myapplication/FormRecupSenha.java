package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class FormRecupSenha extends AppCompatActivity
{
    TextView txtVoltarLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_recup_senha);

        txtVoltarLogin  = findViewById(R.id.txtVoltarLogin);

        txtVoltarLogin.setOnClickListener(v -> {
            startActivity(new Intent(FormRecupSenha.this, TelaLogin.class));
        });
    }
}