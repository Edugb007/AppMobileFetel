package com.example.myapplication;

public class Apostila {

    private String titulo;
    private String descricao;    // ex: "Bimestre 1 · 32 páginas"
    private String nomeArquivo;  // nome do PDF em assets/apostilas/  ex: "port_bim1.pdf"

    public Apostila(String titulo, String descricao, String nomeArquivo) {
        this.titulo       = titulo;
        this.descricao    = descricao;
        this.nomeArquivo  = nomeArquivo;
    }

    public String getTitulo()      { return titulo; }
    public String getDescricao()   { return descricao; }
    public String getNomeArquivo() { return nomeArquivo; }
}
