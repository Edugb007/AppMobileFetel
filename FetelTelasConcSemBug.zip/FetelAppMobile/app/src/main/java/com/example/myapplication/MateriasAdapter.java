package com.example.myapplication;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class MateriasAdapter extends RecyclerView.Adapter<MateriasAdapter.ViewHolder> {

    public interface OnMateriaClick {
        void onClick(Materia materia);
    }

    Context context;
    List<Materia> lista;
    OnMateriaClick listener;

    public MateriasAdapter(Context context, List<Materia> lista, OnMateriaClick listener) {
        this.context  = context;
        this.lista    = lista;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_materia, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Materia materia = lista.get(position);

        holder.txtIcone.setText(materia.getIcone());
        holder.txtNome.setText(materia.getNome());

        int qtd = materia.getApostilas().size();
        holder.txtQtd.setText(qtd + (qtd == 1 ? " apostila" : " apostilas"));

        // Aplica a cor do card
        holder.card.setCardBackgroundColor(materia.getCor());

        holder.itemView.setOnClickListener(v -> listener.onClick(materia));
    }

    @Override
    public int getItemCount() { return lista.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView card;
        TextView txtIcone, txtNome, txtQtd;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            card      = itemView.findViewById(R.id.cardMateria);
            txtIcone  = itemView.findViewById(R.id.txtIconeMateria);
            txtNome   = itemView.findViewById(R.id.txtNomeMateria);
            txtQtd    = itemView.findViewById(R.id.txtQtdApostilas);
        }
    }
}
