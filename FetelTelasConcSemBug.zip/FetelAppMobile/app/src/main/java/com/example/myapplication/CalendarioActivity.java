package com.example.myapplication;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class CalendarioActivity extends AppCompatActivity {

    ImageButton btnVoltar, btnMesAnterior, btnProximoMes;
    TextView txtMesAno;
    GridLayout gridCalendario;
    RecyclerView recyclerEventos;

    Calendar calAtual = Calendar.getInstance();
    Set<Integer> diasComEvento = new HashSet<>();

    String[] nomesMeses = {"Janeiro","Fevereiro","Março","Abril","Maio","Junho",
            "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"};

    // Tamanho das células em dp
    private static final int CELL_SIZE_DP = 44;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);

        btnVoltar       = findViewById(R.id.btnVoltarCalendario);
        btnMesAnterior  = findViewById(R.id.btnMesAnterior);
        btnProximoMes   = findViewById(R.id.btnProximoMes);
        txtMesAno       = findViewById(R.id.txtMesAno);
        gridCalendario  = findViewById(R.id.gridCalendario);
        recyclerEventos = findViewById(R.id.recyclerEventos);

        btnVoltar.setOnClickListener(v -> {
            finish();

        });

        btnMesAnterior.setOnClickListener(v -> {
            calAtual.add(Calendar.MONTH, -1);
            atualizarCalendario();
        });

        btnProximoMes.setOnClickListener(v -> {
            calAtual.add(Calendar.MONTH, 1);
            atualizarCalendario();
        });

        recyclerEventos.setLayoutManager(new LinearLayoutManager(this));
        recyclerEventos.setAdapter(new EventosAdapter(this, criarEventosMock()));

        atualizarCalendario();
    }

    private void atualizarCalendario() {
        int mes = calAtual.get(Calendar.MONTH);
        int ano = calAtual.get(Calendar.YEAR);

        txtMesAno.setText(nomesMeses[mes] + " " + ano);

        diasComEvento.clear();
        diasComEvento.add(12);
        diasComEvento.add(20);
        diasComEvento.add(25);
        diasComEvento.add(7);

        Calendar cal = Calendar.getInstance();
        cal.set(ano, mes, 1);
        int primeiroDiaSemana = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int totalDias = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        Calendar hoje = Calendar.getInstance();
        int diaHoje = (hoje.get(Calendar.MONTH) == mes && hoje.get(Calendar.YEAR) == ano)
                ? hoje.get(Calendar.DAY_OF_MONTH) : -1;

        gridCalendario.removeAllViews();

        for (int i = 0; i < primeiroDiaSemana; i++) {
            gridCalendario.addView(criarCelulaVazia());
        }

        for (int dia = 1; dia <= totalDias; dia++) {
            gridCalendario.addView(criarCelulaDia(dia, dia == diaHoje, diasComEvento.contains(dia)));
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private View criarCelulaVazia() {
        View v = new View(this);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width  = 0;
        params.height = dpToPx(CELL_SIZE_DP);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        v.setLayoutParams(params);
        return v;
    }

    private View criarCelulaDia(int dia, boolean ehHoje, boolean temEvento) {
        TextView tv = new TextView(this);
        tv.setText(String.valueOf(dia));
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(14f);

        int sizePx = dpToPx(CELL_SIZE_DP);
        int innerPx = dpToPx(36); // tamanho do círculo interno

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width  = 0;
        params.height = sizePx;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        tv.setLayoutParams(params);

        if (ehHoje) {
            // Círculo azul sólido — bem destacado
            tv.setBackgroundResource(R.drawable.bg_dia_hoje);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, Typeface.BOLD);
            tv.setTextSize(15f);
            // Adiciona padding para o círculo não ocupar a célula toda
            int pad = (sizePx - innerPx) / 2;
            tv.setPadding(pad, pad, pad, pad);
        } else if (temEvento) {
            // Círculo azul claro com texto azul escuro
            tv.setBackgroundResource(R.drawable.bg_dia_evento);
            tv.setTextColor(Color.parseColor("#005792"));
            tv.setTypeface(null, Typeface.BOLD);
            int pad = (sizePx - innerPx) / 2;
            tv.setPadding(pad, pad, pad, pad);
        } else {
            tv.setTextColor(Color.parseColor("#444444"));
        }

        return tv;
    }

    private ArrayList<Evento> criarEventosMock() {
        ArrayList<Evento> lista = new ArrayList<>();

        lista.add(new Evento(
                "Feira de Ciências",
                "Apresentação de projetos no ginásio",
                12, "MAR", "Evento",
                Color.parseColor("#005792")
        ));
        lista.add(new Evento(
                "Conselho de Classe",
                "Reunião dos professores — sem aula no período",
                20, "MAR", "Institucional",
                Color.parseColor("#E67E22")
        ));
        lista.add(new Evento(
                "Paixão de Cristo",
                "Feriado nacional — não haverá aulas",
                3, "ABR", "Feriado",
                Color.parseColor("#27AE60")
        ));
        lista.add(new Evento(
                "Domingo de Páscoa",
                "Feriado nacional — não haverá aulas",
                5, "ABR", "Feriado",
                Color.parseColor("#8E44AD")
        ));

        return lista;
    }
}
