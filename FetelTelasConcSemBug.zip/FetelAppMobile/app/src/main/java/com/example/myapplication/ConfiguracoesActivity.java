package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class ConfiguracoesActivity extends AppCompatActivity {

    Switch switchTema;
    LinearLayout itemIdioma, itemSobre, itemSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracoes);

        switchTema  = findViewById(R.id.switchTema);
        itemIdioma  = findViewById(R.id.itemIdioma);
        itemSobre   = findViewById(R.id.itemSobre);
        itemSair    = findViewById(R.id.itemSairConfig);

        // ── Voltar ─────────────────────────────────────
        findViewById(R.id.btnVoltarConfig).setOnClickListener(v -> finish());

        // ── Tema claro / escuro ─────────────────────────
        int modo = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        switchTema.setChecked(modo == Configuration.UI_MODE_NIGHT_YES);

        switchTema.setOnCheckedChangeListener((btn, isChecked) -> {
            AppCompatDelegate.setDefaultNightMode(
                    isChecked
                            ? AppCompatDelegate.MODE_NIGHT_YES
                            : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        // ── Idioma (stub — pronto para backend) ─────────
        itemIdioma.setOnClickListener(v ->
                Toast.makeText(this, "Idioma — em breve!", Toast.LENGTH_SHORT).show()
        );

        // ── Sobre o app ─────────────────────────────────
        itemSobre.setOnClickListener(v -> abrirDialogSobre());

        // ── Logout ──────────────────────────────────────
        itemSair.setOnClickListener(v -> {
            Intent intent = new Intent(this, TelaLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });
    }

    private void abrirDialogSobre() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_sobre);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.88f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        dialog.findViewById(R.id.btnFecharSobre).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }
}
