package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class NoticiasActivity extends AppCompatActivity {

    RecyclerView recyclerNoticias;
    ArrayList<Noticia> listaNoticias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticias);

        recyclerNoticias = findViewById(R.id.recyclerNoticias);
        listaNoticias    = new ArrayList<>();

        listaNoticias.add(new Noticia(
                "Feira de Ciências 2026",
                "Os alunos irão apresentar projetos tecnológicos inovadores.",
                "A Feira de Ciências deste ano promete ser a maior da história da escola. " +
                "Os alunos dos cursos técnicos de Informática, Eletrônica e Administração " +
                "apresentarão projetos desenvolvidos ao longo do semestre.\n\n" +
                "O evento acontecerá no ginásio principal, com entrada gratuita para toda " +
                "a comunidade. Serão premiados os três melhores projetos de cada área.",
                "12/03/2026",
                "Evento",
                R.drawable.testetrabalhociencias
        ));

        listaNoticias.add(new Noticia(
                "Calendário de Provas — 1º Semestre",
                "Confira as datas das avaliações bimestrais de todas as turmas.",
                "A coordenação pedagógica divulgou o calendário completo de provas " +
                "do primeiro semestre letivo de 2026.\n\n" +
                "As avaliações bimestrais começam na segunda quinzena de março. " +
                "Alunos com pendências do semestre anterior devem procurar a secretaria " +
                "para regularizar a situação antes do início das provas.\n\n" +
                "O calendário completo está disponível no mural da escola e no site institucional.",
                "08/03/2026",
                "Aviso",
                R.drawable.testetrabalhociencias
        ));

        listaNoticias.add(new Noticia(
                "Semana da Tecnologia ETEC",
                "Palestras, workshops e competições para os alunos de todos os cursos.",
                "A ETEC realizará mais uma edição da Semana da Tecnologia, evento " +
                "que reúne estudantes, professores e profissionais do mercado.\n\n" +
                "A programação inclui palestras com especialistas, workshops práticos " +
                "de programação, design e robótica, além de um hackathon de 12 horas " +
                "com premiação para as melhores equipes.\n\n" +
                "As inscrições para os workshops são gratuitas e podem ser feitas " +
                "diretamente na secretaria da escola.",
                "20/03/2026",
                "Escola",
                R.drawable.testetrabalhociencias
        ));

        recyclerNoticias.setLayoutManager(new LinearLayoutManager(this));
        NoticiasAdapter adapter = new NoticiasAdapter(this, listaNoticias);
        recyclerNoticias.setAdapter(adapter);

        findViewById(R.id.btnVoltar).setOnClickListener(v -> {
            finish();
        });
    }
}
