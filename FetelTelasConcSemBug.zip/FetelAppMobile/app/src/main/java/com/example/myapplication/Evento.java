package com.example.myapplication;

public class Evento {

    private String titulo;
    private String descricao;
    private int dia;
    private String mes;
    private String categoria;
    private int corCategoria; // cor em formato int (ex: Color.parseColor("#005792"))

    public Evento(String titulo, String descricao, int dia, String mes, String categoria, int corCategoria) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dia = dia;
        this.mes = mes;
        this.categoria = categoria;
        this.corCategoria = corCategoria;
    }

    public String getTitulo() { return titulo; }
    public String getDescricao() { return descricao; }
    public int getDia() { return dia; }
    public String getMes() { return mes; }
    public String getCategoria() { return categoria; }
    public int getCorCategoria() { return corCategoria; }
}
