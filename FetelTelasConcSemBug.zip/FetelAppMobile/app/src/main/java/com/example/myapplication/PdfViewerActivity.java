package com.example.myapplication;

import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class PdfViewerActivity extends AppCompatActivity {

    PdfRenderer pdfRenderer;
    PdfRenderer.Page paginaAtual;
    ParcelFileDescriptor fileDescriptor;

    ImageView imgPagina;
    TextView txtPagina, txtTituloPdf;
    ImageButton btnVoltar, btnAnterior, btnProximo;

    int numeroPagina = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        String arquivo = getIntent().getStringExtra("pdf_arquivo");
        String titulo  = getIntent().getStringExtra("pdf_titulo");

        imgPagina    = findViewById(R.id.imgPaginaPdf);
        txtPagina    = findViewById(R.id.txtNumeroPagina);
        txtTituloPdf = findViewById(R.id.txtTituloPdf);
        btnVoltar    = findViewById(R.id.btnVoltarPdf);
        btnAnterior  = findViewById(R.id.btnPaginaAnterior);
        btnProximo   = findViewById(R.id.btnPaginaProxima);

        txtTituloPdf.setText(titulo);

        btnVoltar.setOnClickListener(v -> {
            finish();
        });

        btnAnterior.setOnClickListener(v -> {
            if (numeroPagina > 0) {
                numeroPagina--;
                exibirPagina(numeroPagina);
            }
        });

        btnProximo.setOnClickListener(v -> {
            if (pdfRenderer != null && numeroPagina < pdfRenderer.getPageCount() - 1) {
                numeroPagina++;
                exibirPagina(numeroPagina);
            }
        });

        try {
            abrirPdf(arquivo);
        } catch (IOException e) {
            Toast.makeText(this, "Não foi possível abrir a apostila.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    /**
     * Copia o PDF de assets/ para o cache e abre com PdfRenderer.
     * O PdfRenderer exige um arquivo físico (não funciona direto de InputStream).
     */
    private void abrirPdf(String nomeArquivo) throws IOException {
        // Copia assets/apostilas/<arquivo> → cache
        File cacheFile = new File(getCacheDir(), nomeArquivo);

        if (!cacheFile.exists()) {
            InputStream is = getAssets().open("apostilas/" + nomeArquivo);
            FileOutputStream fos = new FileOutputStream(cacheFile);
            byte[] buffer = new byte[4096];
            int len;
            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            is.close();
        }

        fileDescriptor = ParcelFileDescriptor.open(cacheFile, ParcelFileDescriptor.MODE_READ_ONLY);
        pdfRenderer    = new PdfRenderer(fileDescriptor);

        exibirPagina(0);
    }

    private void exibirPagina(int numero) {
        if (paginaAtual != null) paginaAtual.close();

        paginaAtual = pdfRenderer.openPage(numero);

        // Renderiza em alta resolução (2x a largura da tela)
        int largura = getResources().getDisplayMetrics().widthPixels;
        int altura  = (int) ((float) paginaAtual.getHeight() / paginaAtual.getWidth() * largura);

        Bitmap bitmap = Bitmap.createBitmap(largura, altura, Bitmap.Config.ARGB_8888);
        paginaAtual.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

        imgPagina.setImageBitmap(bitmap);
        txtPagina.setText("Página " + (numero + 1) + " de " + pdfRenderer.getPageCount());

        // Habilita / desabilita botões de navegação
        btnAnterior.setAlpha(numero == 0 ? 0.3f : 1f);
        btnProximo.setAlpha(numero == pdfRenderer.getPageCount() - 1 ? 0.3f : 1f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (paginaAtual != null)   paginaAtual.close();
            if (pdfRenderer != null)   pdfRenderer.close();
            if (fileDescriptor != null) fileDescriptor.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
