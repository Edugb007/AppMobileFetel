package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.snackbar.Snackbar;

public class TelaHome extends AppCompatActivity {

    LinearLayout  btnNoticias;
    LinearLayout  btnFaltasHome;
    LinearLayout  btnBoletimHome;
    ImageView     btnMateriaisHome;
    MaterialCardView cardCalendario, cardCardapio;

    DrawerLayout  drawerLayout;
    LinearLayout  navDrawer;

    private static final String ALUNO_NOME     = "João da Silva";
    private static final String ALUNO_EMAIL    = "joao.silva@etec.sp.gov.br";
    private static final String ALUNO_RA       = "123.456-7";
    private static final String ALUNO_CURSO    = "Técnico em Informática";
    private static final String ALUNO_TURMA    = "3º Ano A — 2026";
    private static final String ALUNO_INICIAIS = "JS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_home);

        btnNoticias      = findViewById(R.id.btnNoticiasHome);
        cardCalendario   = findViewById(R.id.cardCalendarioHome);
        cardCardapio     = findViewById(R.id.cardCardapioHome);
        btnMateriaisHome = findViewById(R.id.btnMateriaisHome);
        btnFaltasHome    = findViewById(R.id.btnFaltasHome);
        btnBoletimHome   = findViewById(R.id.btnBoletimHome);
        drawerLayout     = findViewById(R.id.drawerLayout);
        navDrawer        = findViewById(R.id.navDrawer);

        ((TextView) findViewById(R.id.drawerAvatar)).setText(ALUNO_INICIAIS);
        ((TextView) findViewById(R.id.drawerNome)).setText(ALUNO_NOME);
        ((TextView) findViewById(R.id.drawerEmail)).setText(ALUNO_EMAIL);

        // ── Drawer ─────────────────────────────────────────
        findViewById(R.id.btnMenu).setOnClickListener(v ->
                drawerLayout.openDrawer(navDrawer));

        findViewById(R.id.drawerHeader).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            abrirDialogPerfil();
        });

        findViewById(R.id.drawerItemHome).setOnClickListener(v ->
                drawerLayout.closeDrawer(navDrawer));

        findViewById(R.id.drawerItemNoticias).setOnClickListener(v ->
                startActivity(new Intent(this, NoticiasActivity.class)));

        findViewById(R.id.drawerItemCalendario).setOnClickListener(v ->
                startActivity(new Intent(this, CalendarioActivity.class)));

        findViewById(R.id.drawerItemCardapio).setOnClickListener(v ->
                startActivity(new Intent(this, Cardapio.class)));

        findViewById(R.id.drawerItemApostilas).setOnClickListener(v ->
                startActivity(new Intent(this, MateriasActivity.class)));

        findViewById(R.id.drawerItemConfiguracoes).setOnClickListener(v ->
                startActivity(new Intent(this, ConfiguracoesActivity.class)));

        findViewById(R.id.drawerItemDenuncia).setOnClickListener(v ->
                startActivity(new Intent(this, DenunciaActivity.class)));

        findViewById(R.id.drawerItemContato).setOnClickListener(v ->
                startActivity(new Intent(this, ContatoActivity.class)));

        findViewById(R.id.drawerItemSair).setOnClickListener(v -> {
            Intent intent = new Intent(this, TelaLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        // ── Navegação da Home ───────────────────────────────
        btnNoticias.setOnClickListener(v ->
                startActivity(new Intent(this, NoticiasActivity.class)));

        cardCalendario.setOnClickListener(v ->
                startActivity(new Intent(this, CalendarioActivity.class)));

        cardCardapio.setOnClickListener(v ->
                startActivity(new Intent(this, Cardapio.class)));

        btnMateriaisHome.setOnClickListener(v ->
                startActivity(new Intent(this, MateriasActivity.class)));

        // ── Em desenvolvimento ──────────────────────────────
        btnFaltasHome.setOnClickListener(v -> mostrarEmDesenvolvimento());
        btnBoletimHome.setOnClickListener(v -> mostrarEmDesenvolvimento());
    }

    private void mostrarEmDesenvolvimento() {
        View rootView = findViewById(android.R.id.content);
        Snackbar snackbar = Snackbar.make(rootView, "🚧  Em desenvolvimento — breve!", Snackbar.LENGTH_SHORT);

        View snackbarView = snackbar.getView();

        snackbarView.setBackground(getDrawable(R.drawable.bg_snackbar));

        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) snackbarView.getLayoutParams();
        params.setMargins(48, 0, 48, 80); // Esquerda, Topo, Direita, Baixo
        snackbarView.setLayoutParams(params);

        TextView textView = snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(15);
        textView.setCompoundDrawablePadding(12);

        snackbar.show();
    }

    private void abrirDialogPerfil() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_perfil);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ((TextView) dialog.findViewById(R.id.perfilAvatar)).setText(ALUNO_INICIAIS);
        ((TextView) dialog.findViewById(R.id.perfilNome)).setText(ALUNO_NOME);
        ((TextView) dialog.findViewById(R.id.perfilEmail)).setText(ALUNO_EMAIL);
        ((TextView) dialog.findViewById(R.id.perfilRA)).setText("RA: " + ALUNO_RA);
        ((TextView) dialog.findViewById(R.id.perfilCurso)).setText(ALUNO_CURSO);
        ((TextView) dialog.findViewById(R.id.perfilTurma)).setText(ALUNO_TURMA);

        dialog.findViewById(R.id.btnFecharPerfil).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navDrawer)) {
            drawerLayout.closeDrawer(navDrawer);
        } else {
            super.onBackPressed();
        }
    }
}
