package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.card.MaterialCardView;

public class TelaHome extends AppCompatActivity {

    // Home
    LinearLayout  btnNoticias;
    ImageView     btnMateriaisHome;
    MaterialCardView cardCalendario, cardCardapio;

    // Drawer
    DrawerLayout  drawerLayout;
    LinearLayout  navDrawer;

    // ── Dados mockados do aluno ────────────────────────
    // Futuramente virão de SharedPreferences ou backend
    private static final String ALUNO_NOME    = "João da Silva";
    private static final String ALUNO_EMAIL   = "joao.silva@etec.sp.gov.br";
    private static final String ALUNO_RA      = "123.456-7";
    private static final String ALUNO_CURSO   = "Técnico em Informática";
    private static final String ALUNO_TURMA   = "3º Ano A — 2026";
    private static final String ALUNO_INICIAIS = "JS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_home);

        // ── Bind views da Home ─────────────────────────
        btnNoticias      = findViewById(R.id.btnNoticiasHome);
        cardCalendario   = findViewById(R.id.cardCalendarioHome);
        cardCardapio     = findViewById(R.id.cardCardapioHome);
        btnMateriaisHome = findViewById(R.id.btnMateriaisHome);
        drawerLayout     = findViewById(R.id.drawerLayout);
        navDrawer        = findViewById(R.id.navDrawer);

        // ── Preenche cabeçalho do Drawer ───────────────
        ((TextView) findViewById(R.id.drawerAvatar)).setText(ALUNO_INICIAIS);
        ((TextView) findViewById(R.id.drawerNome)).setText(ALUNO_NOME);
        ((TextView) findViewById(R.id.drawerEmail)).setText(ALUNO_EMAIL);

        // ── Botão hamburguer → abre drawer ────────────
        findViewById(R.id.btnMenu).setOnClickListener(v ->
                drawerLayout.openDrawer(navDrawer));

        // ── Cabeçalho do drawer → abre perfil completo ─
        findViewById(R.id.drawerHeader).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            abrirDialogPerfil();
        });

        // ── Itens de navegação do drawer ──────────────
        findViewById(R.id.drawerItemHome).setOnClickListener(v ->
                drawerLayout.closeDrawer(navDrawer));

        findViewById(R.id.drawerItemNoticias).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, NoticiasActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        findViewById(R.id.drawerItemCalendario).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, CalendarioActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        findViewById(R.id.drawerItemCardapio).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, Cardapio.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        findViewById(R.id.drawerItemApostilas).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, MateriasActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        findViewById(R.id.drawerItemConfiguracoes).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, ConfiguracoesActivity.class));
        });

        findViewById(R.id.drawerItemDenuncia).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            startActivity(new Intent(this, DenunciaActivity.class));
        });

        findViewById(R.id.drawerItemContato).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            Toast.makeText(this, "Contato da Escola — em breve!", Toast.LENGTH_SHORT).show();
        });

        // ── Logout ─────────────────────────────────────
        findViewById(R.id.drawerItemSair).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            Intent intent = new Intent(this, TelaLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        // ── Navegação da Home ──────────────────────────
        btnNoticias.setOnClickListener(v -> {
            startActivity(new Intent(this, NoticiasActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardCalendario.setOnClickListener(v -> {
            startActivity(new Intent(this, CalendarioActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardCardapio.setOnClickListener(v -> {
            startActivity(new Intent(this, Cardapio.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        btnMateriaisHome.setOnClickListener(v -> {
            startActivity(new Intent(this, MateriasActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    // ─────────────────────────────────────────────────────────
    // Dialog de perfil completo do aluno
    // ─────────────────────────────────────────────────────────
    private void abrirDialogPerfil() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_perfil);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        // Preenche campos
        ((TextView) dialog.findViewById(R.id.perfilAvatar)).setText(ALUNO_INICIAIS);
        ((TextView) dialog.findViewById(R.id.perfilNome)).setText(ALUNO_NOME);
        ((TextView) dialog.findViewById(R.id.perfilEmail)).setText(ALUNO_EMAIL);
        ((TextView) dialog.findViewById(R.id.perfilRA)).setText("RA: " + ALUNO_RA);
        ((TextView) dialog.findViewById(R.id.perfilCurso)).setText(ALUNO_CURSO);
        ((TextView) dialog.findViewById(R.id.perfilTurma)).setText(ALUNO_TURMA);

        dialog.findViewById(R.id.btnFecharPerfil).setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    // Botão voltar fecha o drawer se estiver aberto
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navDrawer)) {
            drawerLayout.closeDrawer(navDrawer);
        } else {
            super.onBackPressed();
        }
    }
}
