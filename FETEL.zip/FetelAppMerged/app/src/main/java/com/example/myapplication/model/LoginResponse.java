package com.example.myapplication.model;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {

    // PHP retorna "ok", não "success"
    @SerializedName("ok")
    private boolean ok;

    private String message;

    // PHP retorna "access_token", não "token"
    @SerializedName("access_token")
    private String accessToken;

    @SerializedName("refresh_token")
    private String refreshToken;

    // PHP retorna um objeto "user" com id, email, nome, papel
    private User user;

    public boolean isSuccess() {
        return ok;
    }

    public String getMessage() {
        return message;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public User getUser() {
        return user;
    }

    // Classe interna para o objeto "user" do PHP
    public static class User {
        private int id;
        private String email;
        private String nome;
        private String papel;

        public int getId()     { return id; }
        public String getEmail()  { return email; }
        public String getNome()   { return nome; }
        public String getPapel()  { return papel; }
    }
}
