package com.example.myapplication.model;

// Resposta genérica usada pelos 3 endpoints de recuperação de senha
// PHP retorna: { "ok": true/false, "message": "..." }
public class ApiResponse {
    private boolean ok;
    private String  message;

    public boolean isOk()          { return ok; }
    public String  getMessage()    { return message; }
}