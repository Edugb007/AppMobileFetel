package com.example.myapplication.network;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.concurrent.TimeUnit;

public class ApiClient {

    // ⚠️  Troque pelo IP do seu PC (ipconfig no Windows → IPv4 do adaptador Wi-Fi)
    // Deve ser o mesmo IP que aparece em APP_URL no arquivo .env do PHP
    private static final String BASE_URL = "http://192.168.15.7/TCC-etec/";

    private static Retrofit retrofit;

    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

    /** Chame este método ao trocar de rede para forçar recriar o cliente */
    public static void reset() {
        retrofit = null;
    }
}
