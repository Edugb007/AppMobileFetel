package com.example.myapplication.model;

// ── Request: solicitar código (só e-mail) ──────────────────────────────────
// Usado em: FormRecupSenha → POST /api/senha/solicitar
public class SolicitarCodigoRequest {
    private String email;
    public SolicitarCodigoRequest(String email) { this.email = email; }
    public String getEmail() { return email; }
}