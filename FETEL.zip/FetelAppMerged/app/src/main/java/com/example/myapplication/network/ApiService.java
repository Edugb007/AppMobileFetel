package com.example.myapplication.network;

import com.example.myapplication.model.ApiResponse;
import com.example.myapplication.model.BoletimResponse;
import com.example.myapplication.model.LoginRequest;
import com.example.myapplication.model.LoginResponse;
import com.example.myapplication.model.RedefinirSenhaRequest;
import com.example.myapplication.model.SolicitarCodigoRequest;
import com.example.myapplication.model.VerificarCodigoRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ApiService
{

    // ── Autenticação ──────────────────────────────────────────────────

    @POST("api/login")
    Call<LoginResponse> login(@Body LoginRequest body);

    @POST("api/senha/solicitar")
    Call<ApiResponse> solicitarCodigo(@Body SolicitarCodigoRequest body);

    @POST("api/senha/verificar")
    Call<ApiResponse> verificarCodigo(@Body VerificarCodigoRequest body);

    @POST("api/senha/redefinir")
    Call<ApiResponse> redefinirSenha(@Body RedefinirSenhaRequest body);

    // ── Boletim ───────────────────────────────────────────────────────
    // Authorization: Bearer <access_token>
    @GET("api/aluno/boletim")
    Call<BoletimResponse> getBoletim(@Header("Authorization") String bearerToken);
}