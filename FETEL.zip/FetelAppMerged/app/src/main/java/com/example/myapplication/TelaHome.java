package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.snackbar.Snackbar;

public class TelaHome extends AppCompatActivity {

    LinearLayout     btnNoticias;
    LinearLayout     btnFaltasHome;
    LinearLayout     btnBoletimHome;
    ImageView        btnMateriaisHome;
    MaterialCardView cardCalendario, cardCardapio;

    DrawerLayout drawerLayout;
    LinearLayout navDrawer;

    // Dados do usuário lidos do SharedPreferences após o login
    private String alunoNome;
    private String alunoEmail;
    private String alunoPapel;
    private int    alunoId;
    private String alunoIniciais;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_home);

        // ── Carrega dados reais do usuário logado ──────────────────
        carregarDadosUsuario();

        btnNoticias      = findViewById(R.id.btnNoticiasHome);
        cardCalendario   = findViewById(R.id.cardCalendarioHome);
        cardCardapio     = findViewById(R.id.cardCardapioHome);
        btnMateriaisHome = findViewById(R.id.btnMateriaisHome);
        btnFaltasHome    = findViewById(R.id.btnFaltasHome);
        btnBoletimHome   = findViewById(R.id.btnBoletimHome);
        drawerLayout     = findViewById(R.id.drawerLayout);
        navDrawer        = findViewById(R.id.navDrawer);

        // Preenche o drawer com dados reais
        ((TextView) findViewById(R.id.drawerAvatar)).setText(alunoIniciais);
        ((TextView) findViewById(R.id.drawerNome)).setText(alunoNome);
        ((TextView) findViewById(R.id.drawerEmail)).setText(alunoEmail);

        // ── Drawer ─────────────────────────────────────────────────
        findViewById(R.id.btnMenu).setOnClickListener(v ->
                drawerLayout.openDrawer(navDrawer));

        // "Ver carteirinha" abre a carteirinha digital
        findViewById(R.id.drawerHeader).setOnClickListener(v -> {
            drawerLayout.closeDrawer(navDrawer);
            abrirCarteirinha();
        });

        findViewById(R.id.drawerItemHome).setOnClickListener(v ->
                drawerLayout.closeDrawer(navDrawer));

        findViewById(R.id.drawerItemNoticias).setOnClickListener(v ->
                startActivity(new Intent(this, NoticiasActivity.class)));

        findViewById(R.id.drawerItemCalendario).setOnClickListener(v ->
                startActivity(new Intent(this, CalendarioActivity.class)));

        findViewById(R.id.drawerItemCardapio).setOnClickListener(v ->
                startActivity(new Intent(this, Cardapio.class)));

        findViewById(R.id.drawerItemApostilas).setOnClickListener(v ->
                startActivity(new Intent(this, MateriasActivity.class)));

        findViewById(R.id.drawerItemConfiguracoes).setOnClickListener(v ->
                startActivity(new Intent(this, ConfiguracoesActivity.class)));

        findViewById(R.id.drawerItemDenuncia).setOnClickListener(v ->
                startActivity(new Intent(this, DenunciaActivity.class)));

        findViewById(R.id.drawerItemContato).setOnClickListener(v ->
                startActivity(new Intent(this, ContatoActivity.class)));

        findViewById(R.id.drawerItemSair).setOnClickListener(v -> {
            getSharedPreferences("sessao", MODE_PRIVATE).edit().clear().apply();
            Intent intent = new Intent(this, TelaLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });

        // ── Navegação da Home ───────────────────────────────────────
        btnNoticias.setOnClickListener(v ->
                startActivity(new Intent(this, NoticiasActivity.class)));

        cardCalendario.setOnClickListener(v ->
                startActivity(new Intent(this, CalendarioActivity.class)));

        cardCardapio.setOnClickListener(v ->
                startActivity(new Intent(this, Cardapio.class)));

        btnMateriaisHome.setOnClickListener(v ->
                startActivity(new Intent(this, MateriasActivity.class)));

        btnFaltasHome.setOnClickListener(v -> mostrarEmDesenvolvimento());

        // ── Boletim ────────────────────────────────────────────────
        btnBoletimHome.setOnClickListener(v ->
                startActivity(new Intent(this, BoletimActivity.class)));
    }

    // ── Lê os dados salvos pelo TelaLogin após autenticação bem-sucedida ──
    private void carregarDadosUsuario() {
        SharedPreferences prefs = getSharedPreferences("sessao", MODE_PRIVATE);

        alunoId    = prefs.getInt("user_id", 0);
        alunoNome  = prefs.getString("user_nome",  "Usuário");
        alunoEmail = prefs.getString("user_email", "");
        alunoPapel = prefs.getString("user_papel", "");

        // Gera as iniciais a partir do nome (ex: "João da Silva" → "JS")
        alunoIniciais = gerarIniciais(alunoNome);
    }

    private String gerarIniciais(String nome) {
        if (nome == null || nome.trim().isEmpty()) return "?";
        String[] partes = nome.trim().split("\\s+");
        if (partes.length == 1) {
            return partes[0].substring(0, Math.min(2, partes[0].length())).toUpperCase();
        }
        // Pega a primeira e a última palavra
        String primeira = partes[0];
        String ultima   = partes[partes.length - 1];
        return (String.valueOf(primeira.charAt(0)) + String.valueOf(ultima.charAt(0))).toUpperCase();
    }

    // ── Abre a carteirinha digital com os dados reais do usuário ──
    private void abrirCarteirinha() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_carteirinha);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.92f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        // Preenche os campos com dados reais
        ((TextView) dialog.findViewById(R.id.carteirinhaIniciais)).setText(alunoIniciais);
        ((TextView) dialog.findViewById(R.id.carteirinhaNome)).setText(alunoNome);
        ((TextView) dialog.findViewById(R.id.carteirinhaEmail)).setText(alunoEmail);
        ((TextView) dialog.findViewById(R.id.carteirinhaPapel)).setText(
                alunoPapel != null && !alunoPapel.isEmpty() ? alunoPapel.toUpperCase() : "ALUNO"
        );
        ((TextView) dialog.findViewById(R.id.carteirinhaId)).setText(
                "ID " + String.format("%04d", alunoId)
        );

        dialog.findViewById(R.id.btnFecharCarteirinha).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void mostrarEmDesenvolvimento() {
        View rootView = findViewById(android.R.id.content);
        Snackbar snackbar = Snackbar.make(rootView, "🚧  Em desenvolvimento — breve!", Snackbar.LENGTH_SHORT);

        View snackbarView = snackbar.getView();
        snackbarView.setBackground(getDrawable(R.drawable.bg_snackbar));

        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) snackbarView.getLayoutParams();
        params.setMargins(48, 0, 48, 80);
        snackbarView.setLayoutParams(params);

        TextView textView = snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(15);
        textView.setCompoundDrawablePadding(12);

        snackbar.show();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(navDrawer)) {
            drawerLayout.closeDrawer(navDrawer);
        } else {
            super.onBackPressed();
        }
    }
}