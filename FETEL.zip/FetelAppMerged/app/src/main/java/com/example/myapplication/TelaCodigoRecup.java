package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.myapplication.model.ApiResponse;
import com.example.myapplication.model.SolicitarCodigoRequest;
import com.example.myapplication.model.VerificarCodigoRequest;
import com.example.myapplication.network.ApiClient;
import com.example.myapplication.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TelaCodigoRecup extends AppCompatActivity {

    EditText        txtCodigoRecup;
    AppCompatButton btnEnviarCod;
    TextView        txtReenviarCod;
    TextView        txtEmailHint;   // mostra "Código enviado para x@..."

    String email; // recebido da tela anterior
    CountDownTimer reenvioTimer;
    boolean podeReenviar = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_codigo_recup);

        // Recebe o e-mail passado pela FormRecupSenha
        email = getIntent().getStringExtra("email");
        if (email == null || email.isEmpty()) {
            Toast.makeText(this, "Erro: e-mail não recebido.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        txtCodigoRecup = findViewById(R.id.txtCodigoRecup);
        btnEnviarCod   = findViewById(R.id.btnEnviarCod);
        txtReenviarCod = findViewById(R.id.txtReenviarCod);

        btnEnviarCod.setOnClickListener(v -> verificarCodigo());
        txtReenviarCod.setOnClickListener(v -> { if (podeReenviar) reenviarCodigo(); });

        // Inicia o contador de 60s para reenvio
        iniciarContadorReenvio();
    }

    private void verificarCodigo() {
        String codigo = txtCodigoRecup.getText().toString().trim();

        if (TextUtils.isEmpty(codigo) || codigo.length() != 6) {
            txtCodigoRecup.setError("Digite o código de 6 dígitos");
            txtCodigoRecup.requestFocus();
            return;
        }

        btnEnviarCod.setEnabled(false);
        btnEnviarCod.setText("Verificando...");

        ApiService api = ApiClient.getRetrofitInstance().create(ApiService.class);
        api.verificarCodigo(new VerificarCodigoRequest(email, codigo))
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        btnEnviarCod.setEnabled(true);
                        btnEnviarCod.setText("Verificar");

                        if (response.isSuccessful() && response.body() != null && response.body().isOk()) {
                            // Código válido → vai para a tela de nova senha, passando email + código
                            Intent intent = new Intent(TelaCodigoRecup.this, NovaSenha.class);
                            intent.putExtra("email",  email);
                            intent.putExtra("codigo", codigo);
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        } else {
                            String msg = (response.body() != null && response.body().getMessage() != null)
                                    ? response.body().getMessage()
                                    : "Código inválido ou expirado.";
                            Toast.makeText(TelaCodigoRecup.this, msg, Toast.LENGTH_SHORT).show();
                            txtCodigoRecup.setBackground(getDrawable(R.drawable.bg_input_erro));
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        btnEnviarCod.setEnabled(true);
                        btnEnviarCod.setText("Verificar");
                        Toast.makeText(TelaCodigoRecup.this,
                                "Sem conexão com o servidor.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void reenviarCodigo() {
        podeReenviar = false;
        txtReenviarCod.setAlpha(0.4f);
        txtReenviarCod.setText("Reenviar código");

        ApiService api = ApiClient.getRetrofitInstance().create(ApiService.class);
        api.solicitarCodigo(new SolicitarCodigoRequest(email))
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        Toast.makeText(TelaCodigoRecup.this,
                                "Novo código enviado!", Toast.LENGTH_SHORT).show();
                        iniciarContadorReenvio();
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        Toast.makeText(TelaCodigoRecup.this,
                                "Sem conexão com o servidor.", Toast.LENGTH_SHORT).show();
                        podeReenviar = true;
                        txtReenviarCod.setAlpha(1f);
                    }
                });
    }

    // Contador regressivo de 60s para liberar o botão de reenvio
    private void iniciarContadorReenvio() {
        podeReenviar = false;
        txtReenviarCod.setAlpha(0.4f);

        if (reenvioTimer != null) reenvioTimer.cancel();

        reenvioTimer = new CountDownTimer(60_000, 1_000) {
            @Override
            public void onTick(long ms) {
                txtReenviarCod.setText("Reenviar em " + (ms / 1000) + "s");
            }

            @Override
            public void onFinish() {
                podeReenviar = true;
                txtReenviarCod.setText("Não recebeu o código? Reenviar");
                txtReenviarCod.setAlpha(1f);
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (reenvioTimer != null) reenvioTimer.cancel();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}