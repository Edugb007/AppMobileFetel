package com.example.myapplication.model;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

/**
 * Representa uma disciplina no boletim do aluno.
 */
public class Disciplina {

    private String nome;
    private String professor;

    /** Mapa de bimestre → nota  (chave "1", "2", "3", "4"; valor null = sem nota) */
    private Map<String, Double> notas;

    /** Média calculada pelo servidor (null se não houver notas ainda) */
    private Double media;

    /** "aprovado", "reprovado" ou "pendente" */
    private String situacao;

    // ── Getters ──────────────────────────────────────────────────────

    public String getNome()       { return nome; }
    public String getProfessor()  { return professor != null ? professor : ""; }
    public Map<String, Double> getNotas() { return notas; }
    public Double getMedia()      { return media; }
    public String getSituacao()   { return situacao != null ? situacao : "pendente"; }

    /** Retorna a nota de um bimestre específico (1‑4), ou null se não lançada. */
    public Double getNotaBimestre(int bimestre) {
        if (notas == null) return null;
        return notas.get(String.valueOf(bimestre));
    }

    /** Formata a nota para exibição: "7,50" ou "—" se null. */
    public static String formatar(Double nota) {
        if (nota == null) return "—";
        return String.format("%.2f", nota).replace('.', ',');
    }
}