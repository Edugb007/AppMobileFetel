package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.myapplication.model.LoginRequest;
import com.example.myapplication.model.LoginResponse;
import com.example.myapplication.network.ApiClient;
import com.example.myapplication.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TelaLogin extends AppCompatActivity {

    EditText txtEmail, txtSenha;
    AppCompatButton btnLogar;
    TextView txtRecupSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        txtEmail      = findViewById(R.id.txtEmail);
        txtSenha      = findViewById(R.id.txtSenha);
        btnLogar      = findViewById(R.id.btnLogar);
        txtRecupSenha = findViewById(R.id.txtRecupSenha);

        btnLogar.setOnClickListener(v -> tentarLogin());

        txtRecupSenha.setOnClickListener(v -> {
            startActivity(new Intent(TelaLogin.this, FormRecupSenha.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void tentarLogin() {
        String email = txtEmail.getText().toString().trim();
        String senha = txtSenha.getText().toString().trim();

        // Resetar bordas
        txtEmail.setBackground(getDrawable(R.drawable.bg_input));
        txtSenha.setBackground(getDrawable(R.drawable.bg_input));

        if (TextUtils.isEmpty(email)) {
            txtEmail.setBackground(getDrawable(R.drawable.bg_input_erro));
            txtEmail.setError("Preencha o e-mail");
            txtEmail.requestFocus();
            shakeView(txtEmail);
            return;
        }

        if (TextUtils.isEmpty(senha)) {
            txtSenha.setBackground(getDrawable(R.drawable.bg_input_erro));
            txtSenha.setError("Preencha a senha");
            txtSenha.requestFocus();
            shakeView(txtSenha);
            return;
        }

        // Desabilitar botão durante a requisição
        btnLogar.setEnabled(false);
        btnLogar.setText("Entrando...");

        fazerLoginApi(email, senha);
    }

    private void fazerLoginApi(String email, String senha) {
        ApiService apiService = ApiClient.getRetrofitInstance().create(ApiService.class);
        LoginRequest request  = new LoginRequest(email, senha);

        apiService.login(request).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                btnLogar.setEnabled(true);
                btnLogar.setText("Entrar");

                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().isSuccess()) {
                        // Salva token e dados do usuário para uso futuro
                        SharedPreferences prefs = getSharedPreferences("sessao", MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("access_token",  response.body().getAccessToken());
                        editor.putString("refresh_token", response.body().getRefreshToken());
                        if (response.body().getUser() != null) {
                            editor.putInt("user_id",       response.body().getUser().getId());
                            editor.putString("user_email", response.body().getUser().getEmail());
                            editor.putString("user_nome",  response.body().getUser().getNome());
                            editor.putString("user_papel", response.body().getUser().getPapel());
                        }
                        editor.apply();
                        irParaHome();
                    } else {
                        String msg = response.body().getMessage();
                        android.util.Log.e("LOGIN", "ok=false | message=" + msg);
                        Toast.makeText(TelaLogin.this,
                                msg != null ? msg : "E-mail ou senha incorretos",
                                Toast.LENGTH_SHORT).show();

                        txtEmail.setBackground(getDrawable(R.drawable.bg_input_erro));
                        txtSenha.setBackground(getDrawable(R.drawable.bg_input_erro));
                        shakeView(txtEmail);
                        shakeView(txtSenha);
                    }
                } else {
                    String errorBody = "";
                    try { errorBody = response.errorBody().string(); } catch (Exception ignored) {}
                    android.util.Log.e("LOGIN", "HTTP " + response.code() + " | " + errorBody);
                    Toast.makeText(TelaLogin.this, "Erro no servidor. Tente novamente.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                btnLogar.setEnabled(true);
                btnLogar.setText("Entrar");
                Toast.makeText(TelaLogin.this, "Sem conexão com o servidor.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void irParaHome() {
        btnLogar.animate()
                .scaleX(0.96f).scaleY(0.96f)
                .setDuration(100)
                .withEndAction(() -> {
                    btnLogar.animate().scaleX(1f).scaleY(1f).setDuration(100).start();

                    Intent intent = new Intent(TelaLogin.this, TelaHome.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                })
                .start();
    }

    private void shakeView(View view) {
        view.animate().translationX(12f).setDuration(60)
            .withEndAction(() ->
                view.animate().translationX(-12f).setDuration(60)
                .withEndAction(() ->
                    view.animate().translationX(8f).setDuration(50)
                    .withEndAction(() ->
                        view.animate().translationX(0f).setDuration(50).start()
                    ).start()
                ).start()
            ).start();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
