package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.myapplication.model.ApiResponse;
import com.example.myapplication.model.SolicitarCodigoRequest;
import com.example.myapplication.network.ApiClient;
import com.example.myapplication.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FormRecupSenha extends AppCompatActivity {

    EditText        txtEmailRecup;
    AppCompatButton btnEnviarEmail;
    TextView        txtVoltarLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_recup_senha);

        txtEmailRecup  = findViewById(R.id.txtEmailRecup);
        btnEnviarEmail = findViewById(R.id.btnEnviarEmail);
        txtVoltarLogin = findViewById(R.id.txtVoltarLogin);

        btnEnviarEmail.setOnClickListener(v -> enviarCodigo());

        txtVoltarLogin.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });
    }

    private void enviarCodigo() {
        String email = txtEmailRecup.getText().toString().trim().toLowerCase();

        if (TextUtils.isEmpty(email)) {
            txtEmailRecup.setError("Preencha o e-mail");
            txtEmailRecup.requestFocus();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            txtEmailRecup.setError("E-mail inválido");
            txtEmailRecup.requestFocus();
            return;
        }

        btnEnviarEmail.setEnabled(false);
        btnEnviarEmail.setText("Enviando...");

        ApiService api = ApiClient.getRetrofitInstance().create(ApiService.class);
        api.solicitarCodigo(new SolicitarCodigoRequest(email))
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        btnEnviarEmail.setEnabled(true);
                        btnEnviarEmail.setText("Enviar código");

                        // ok=true mesmo se e-mail não existir (para não vazar dados)
                        // então sempre avança para a tela de código
                        if (response.isSuccessful() && response.body() != null) {
                            // Passa o e-mail para a próxima tela via Intent
                            Intent intent = new Intent(FormRecupSenha.this, TelaCodigoRecup.class);
                            intent.putExtra("email", email);
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        } else {
                            Toast.makeText(FormRecupSenha.this,
                                    "Erro ao enviar código. Tente novamente.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        btnEnviarEmail.setEnabled(true);
                        btnEnviarEmail.setText("Enviar código");
                        Toast.makeText(FormRecupSenha.this,
                                "Sem conexão com o servidor.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}