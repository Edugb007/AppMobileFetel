package com.example.myapplication.model;

public class LoginRequest {

    private String email;
    private String password; // PHP espera "password", não "senha"

    public LoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
