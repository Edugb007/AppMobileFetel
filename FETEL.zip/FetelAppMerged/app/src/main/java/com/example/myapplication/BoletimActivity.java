package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.model.BoletimResponse;
import com.example.myapplication.network.ApiClient;
import com.example.myapplication.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BoletimActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private RecyclerView recyclerBoletim;
    private TextView tvErro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boletim);

        ImageButton btnVoltar = findViewById(R.id.btnVoltarBoletim);
        btnVoltar.setOnClickListener(v -> finish());

        progressBar     = findViewById(R.id.progressBoletim);
        recyclerBoletim = findViewById(R.id.recyclerBoletim);
        tvErro          = findViewById(R.id.tvBoletimErro);

        recyclerBoletim.setLayoutManager(new LinearLayoutManager(this));

        carregarBoletim();
    }

    private void carregarBoletim() {
        // Recupera o access_token salvo pelo TelaLogin
        SharedPreferences prefs = getSharedPreferences("sessao", MODE_PRIVATE);
        String token = prefs.getString("access_token", "");

        if (token.isEmpty()) {
            mostrarErro("Sessão expirada. Faça login novamente.");
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        recyclerBoletim.setVisibility(View.GONE);
        tvErro.setVisibility(View.GONE);

        ApiService api = ApiClient.getRetrofitInstance().create(ApiService.class);
        api.getBoletim("Bearer " + token).enqueue(new Callback<BoletimResponse>() {

            @Override
            public void onResponse(Call<BoletimResponse> call, Response<BoletimResponse> response) {
                progressBar.setVisibility(View.GONE);

                if (!response.isSuccessful() || response.body() == null) {
                    mostrarErro("Erro ao buscar boletim (código " + response.code() + ").");
                    return;
                }

                BoletimResponse body = response.body();
                if (!body.isOk()) {
                    mostrarErro(body.getMessage() != null ? body.getMessage() : "Erro desconhecido.");
                    return;
                }

                if (body.getDisciplinas() == null || body.getDisciplinas().isEmpty()) {
                    mostrarErro("Nenhuma nota lançada ainda.");
                    return;
                }

                BoletimAdapter adapter = new BoletimAdapter(BoletimActivity.this, body.getDisciplinas());
                recyclerBoletim.setAdapter(adapter);
                recyclerBoletim.setVisibility(View.VISIBLE);
            }

            @Override
            public void onFailure(Call<BoletimResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                mostrarErro("Sem conexão com o servidor.");
            }
        });
    }

    private void mostrarErro(String msg) {
        tvErro.setText(msg);
        tvErro.setVisibility(View.VISIBLE);
        recyclerBoletim.setVisibility(View.GONE);
    }
}