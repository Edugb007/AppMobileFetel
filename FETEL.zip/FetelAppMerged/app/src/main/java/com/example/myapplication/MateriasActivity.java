package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MateriasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias);

        ImageButton btnVoltar = findViewById(R.id.btnVoltarMaterias);
        btnVoltar.setOnClickListener(v -> {
            finish();
        });

        RecyclerView recycler = findViewById(R.id.recyclerMaterias);
        recycler.setLayoutManager(new GridLayoutManager(this, 2));

        List<Materia> materias = criarMaterias();
        MateriasAdapter adapter = new MateriasAdapter(this, materias, materia -> {
            Intent intent = new Intent(this, ApostilasActivity.class);
            intent.putExtra("materia_nome",  materia.getNome());
            intent.putExtra("materia_icone", materia.getIcone());
            intent.putExtra("materia_cor",   materia.getCor());

            // Passa as apostilas como arrays simples
            String[] titulos   = new String[materia.getApostilas().size()];
            String[] descricoes = new String[materia.getApostilas().size()];
            String[] arquivos  = new String[materia.getApostilas().size()];
            for (int i = 0; i < materia.getApostilas().size(); i++) {
                titulos[i]    = materia.getApostilas().get(i).getTitulo();
                descricoes[i] = materia.getApostilas().get(i).getDescricao();
                arquivos[i]   = materia.getApostilas().get(i).getNomeArquivo();
            }
            intent.putExtra("apostilas_titulos",   titulos);
            intent.putExtra("apostilas_descricoes", descricoes);
            intent.putExtra("apostilas_arquivos",  arquivos);

            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
        recycler.setAdapter(adapter);
    }

    private List<Materia> criarMaterias() {
        List<Materia> lista = new ArrayList<>();

        lista.add(new Materia("Português", "📖",
                Color.parseColor("#1565C0"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Gramática e interpretação · 28 págs.", "port_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Literatura brasileira · 34 págs.",     "port_bim2.pdf")
                )));

        lista.add(new Materia("Matemática", "📐",
                Color.parseColor("#6A1B9A"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Funções e equações · 30 págs.",        "mat_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Geometria analítica · 26 págs.",       "mat_bim2.pdf")
                )));

        lista.add(new Materia("História", "🏛️",
                Color.parseColor("#BF360C"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Brasil República · 24 págs.",          "hist_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Guerra Fria · 22 págs.",               "hist_bim2.pdf")
                )));

        lista.add(new Materia("Geografia", "🌍",
                Color.parseColor("#2E7D32"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Geopolítica mundial · 20 págs.",       "geo_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Urbanização · 18 págs.",               "geo_bim2.pdf")
                )));

        lista.add(new Materia("Ciências", "🔬",
                Color.parseColor("#00695C"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Química orgânica · 32 págs.",          "cien_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Física ondulatória · 28 págs.",        "cien_bim2.pdf")
                )));

        lista.add(new Materia("Informática", "💻",
                Color.parseColor("#051233"),
                Arrays.asList(
                        new Apostila("Apostila — 1º Bimestre", "Lógica de programação · 40 págs.",     "info_bim1.pdf"),
                        new Apostila("Apostila — 2º Bimestre", "Banco de dados · 36 págs.",            "info_bim2.pdf")
                )));

        return lista;
    }
}
