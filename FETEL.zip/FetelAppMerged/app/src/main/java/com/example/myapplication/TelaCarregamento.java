package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class TelaCarregamento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_carregamento);

        new Handler(Looper.getMainLooper()).postDelayed(this::verificarSessao, 2500);
    }

    private void verificarSessao() {
        SharedPreferences prefs = getSharedPreferences("sessao", MODE_PRIVATE);
        String token = prefs.getString("access_token", null);

        Class<?> destino = (token != null && !token.isEmpty()) ? TelaHome.class : TelaLogin.class;

        Intent intent = new Intent(TelaCarregamento.this, destino);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_login_enter, R.anim.slide_login_exit);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}