package com.example.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.model.Disciplina;

import java.util.List;

public class BoletimAdapter extends RecyclerView.Adapter<BoletimAdapter.ViewHolder> {

    private final Context context;
    private final List<Disciplina> disciplinas;

    public BoletimAdapter(Context context, List<Disciplina> disciplinas) {
        this.context = context;
        this.disciplinas = disciplinas;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context)
                .inflate(R.layout.item_boletim_disciplina, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Disciplina d = disciplinas.get(position);

        h.tvNome.setText(d.getNome());
        h.tvProfessor.setText(d.getProfessor().isEmpty() ? "" : "Prof. " + d.getProfessor());

        h.tvN1.setText(Disciplina.formatar(d.getNotaBimestre(1)));
        h.tvN2.setText(Disciplina.formatar(d.getNotaBimestre(2)));
        h.tvN3.setText(Disciplina.formatar(d.getNotaBimestre(3)));
        h.tvN4.setText(Disciplina.formatar(d.getNotaBimestre(4)));

        // Média
        String mediaTexto = Disciplina.formatar(d.getMedia());
        h.tvMedia.setText(mediaTexto);

        // Cor da situação
        switch (d.getSituacao()) {
            case "aprovado":
                h.tvSituacao.setText("✓ Aprovado");
                h.tvSituacao.setTextColor(Color.parseColor("#2E7D32")); // verde
                h.tvMedia.setTextColor(Color.parseColor("#2E7D32"));
                break;
            case "reprovado":
                h.tvSituacao.setText("✗ Reprovado");
                h.tvSituacao.setTextColor(Color.parseColor("#C62828")); // vermelho
                h.tvMedia.setTextColor(Color.parseColor("#C62828"));
                break;
            default:
                h.tvSituacao.setText("— Pendente");
                h.tvSituacao.setTextColor(Color.parseColor("#757575")); // cinza
                h.tvMedia.setTextColor(Color.parseColor("#757575"));
                break;
        }
    }

    @Override
    public int getItemCount() { return disciplinas.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNome, tvProfessor, tvN1, tvN2, tvN3, tvN4, tvMedia, tvSituacao;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNome      = itemView.findViewById(R.id.tvDisciplinaNome);
            tvProfessor = itemView.findViewById(R.id.tvDisciplinaProfessor);
            tvN1        = itemView.findViewById(R.id.tvNota1);
            tvN2        = itemView.findViewById(R.id.tvNota2);
            tvN3        = itemView.findViewById(R.id.tvNota3);
            tvN4        = itemView.findViewById(R.id.tvNota4);
            tvMedia     = itemView.findViewById(R.id.tvMedia);
            tvSituacao  = itemView.findViewById(R.id.tvSituacao);
        }
    }
}