package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.myapplication.model.ApiResponse;
import com.example.myapplication.model.RedefinirSenhaRequest;
import com.example.myapplication.network.ApiClient;
import com.example.myapplication.network.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NovaSenha extends AppCompatActivity {

    EditText        txtNovaSenha, txtConfirmaSenha;
    AppCompatButton btnNovaSenha;
    TextView        lblSeuEmail;

    String email;
    String codigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nova_senha);

        // Recebe email e código verificado da tela anterior
        email  = getIntent().getStringExtra("email");
        codigo = getIntent().getStringExtra("codigo");

        if (email == null || codigo == null) {
            Toast.makeText(this, "Erro: dados de verificação não recebidos.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        txtNovaSenha     = findViewById(R.id.txtNovaSenha);
        txtConfirmaSenha = findViewById(R.id.txtConfirmaSenha);
        btnNovaSenha     = findViewById(R.id.btnNovaSenha);
        lblSeuEmail      = findViewById(R.id.lblSeuEmail);

        // Mostra para qual e-mail está redefinindo
        lblSeuEmail.setText("definindo senha para: " + email);

        btnNovaSenha.setOnClickListener(v -> redefinirSenha());
    }

    private void redefinirSenha() {
        String nova     = txtNovaSenha.getText().toString();
        String confirma = txtConfirmaSenha.getText().toString();

        // Validações
        if (TextUtils.isEmpty(nova)) {
            txtNovaSenha.setError("Preencha a nova senha");
            txtNovaSenha.requestFocus();
            return;
        }

        if (nova.length() < 6) {
            txtNovaSenha.setError("A senha deve ter pelo menos 6 caracteres");
            txtNovaSenha.requestFocus();
            return;
        }

        if (!nova.equals(confirma)) {
            txtConfirmaSenha.setError("As senhas não coincidem");
            txtConfirmaSenha.requestFocus();
            txtConfirmaSenha.setBackground(getDrawable(R.drawable.bg_input_erro));
            return;
        }

        btnNovaSenha.setEnabled(false);
        btnNovaSenha.setText("Salvando...");

        ApiService api = ApiClient.getRetrofitInstance().create(ApiService.class);
        api.redefinirSenha(new RedefinirSenhaRequest(email, codigo, nova))
                .enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        btnNovaSenha.setEnabled(true);
                        btnNovaSenha.setText("Redefinir Senha");

                        if (response.isSuccessful() && response.body() != null && response.body().isOk()) {
                            // Sucesso! Vai para a tela de confirmação
                            Intent intent = new Intent(NovaSenha.this, SucessoNovaSenha.class);
                            // Limpa o back stack até o login para o usuário não voltar
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                        } else {
                            String msg = (response.body() != null && response.body().getMessage() != null)
                                    ? response.body().getMessage()
                                    : "Erro ao redefinir senha. Solicite um novo código.";
                            Toast.makeText(NovaSenha.this, msg, Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        btnNovaSenha.setEnabled(true);
                        btnNovaSenha.setText("Redefinir Senha");
                        Toast.makeText(NovaSenha.this,
                                "Sem conexão com o servidor.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}