package com.example.myapplication;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cardapio extends AppCompatActivity {

    LinearLayout layoutDias;
    LinearLayout layoutItensCafe, layoutItensAlmoco, layoutItensLanche;
    TextView txtDataCompleta;
    ImageButton btnVoltar;

    int diaSelecionado = 0;
    TextView[] botoesdias = new TextView[5];

    String[] nomesDias     = {"Seg", "Ter", "Qua", "Qui", "Sex"};
    String[] nomesDiasFull = {"Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira"};

    Map<Integer, Map<String, List<String>>> cardapioMock = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardapio);

        btnVoltar         = findViewById(R.id.btnVoltarCardapio);
        layoutDias        = findViewById(R.id.layoutDias);
        txtDataCompleta   = findViewById(R.id.txtDataCompleta);
        layoutItensCafe   = findViewById(R.id.layoutItensCafe);
        layoutItensAlmoco = findViewById(R.id.layoutItensAlmoco);
        layoutItensLanche = findViewById(R.id.layoutItensLanche);

        btnVoltar.setOnClickListener(v -> {
            finish();
        });

        popularCardapioMock();
        criarBotoesDias();
        selecionarDiaAtual();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private void selecionarDiaAtual() {
        int diaSemana = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
        int indice = diaSemana - 2;
        if (indice < 0 || indice > 4) indice = 0;
        selecionarDia(indice);
    }

    private void criarBotoesDias() {
        Typeface fonte = ResourcesCompat.getFont(this, R.font.sf_pro);

        for (int i = 0; i < 5; i++) {
            final int indice = i;
            TextView btn = new TextView(this);
            btn.setText(nomesDias[i]);
            btn.setTypeface(fonte, Typeface.BOLD);
            btn.setTextSize(13f);
            btn.setGravity(android.view.Gravity.CENTER);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    dpParaPx(68), dpParaPx(42)
            );
            params.setMarginEnd(dpParaPx(8));
            btn.setLayoutParams(params);

            btn.setOnClickListener(v -> selecionarDia(indice));

            botoesdias[i] = btn;
            layoutDias.addView(btn);
        }
    }

    private void selecionarDia(int indice) {
        diaSelecionado = indice;

        for (int i = 0; i < 5; i++) {
            if (i == indice) {
                botoesdias[i].setBackgroundResource(R.drawable.bg_dia_selecionado);
                botoesdias[i].setTextColor(Color.WHITE);
            } else {
                botoesdias[i].setBackgroundResource(R.drawable.bg_dia_normal);
                botoesdias[i].setTextColor(Color.parseColor("#666666"));
            }
        }

        txtDataCompleta.setText(nomesDiasFull[indice] + " · Semana atual");

        Map<String, List<String>> refeicoes = cardapioMock.get(indice);
        if (refeicoes != null) {
            popularItens(layoutItensCafe,   refeicoes.get("cafe"));
            popularItens(layoutItensAlmoco, refeicoes.get("almoco"));
            popularItens(layoutItensLanche, refeicoes.get("lanche"));
        }
    }

    private void popularItens(LinearLayout layout, List<String> itens) {
        layout.removeAllViews();
        if (itens == null) return;

        Typeface fonte = ResourcesCompat.getFont(this, R.font.sf_pro);

        for (String item : itens) {
            LinearLayout linha = new LinearLayout(this);
            linha.setOrientation(LinearLayout.HORIZONTAL);
            linha.setGravity(android.view.Gravity.CENTER_VERTICAL);

            LinearLayout.LayoutParams paramsLinha = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            paramsLinha.bottomMargin = dpParaPx(10);
            linha.setLayoutParams(paramsLinha);

            View bolinha = new View(this);
            LinearLayout.LayoutParams paramsBolinha = new LinearLayout.LayoutParams(
                    dpParaPx(7), dpParaPx(7)
            );
            paramsBolinha.setMarginEnd(dpParaPx(10));
            bolinha.setLayoutParams(paramsBolinha);
            bolinha.setBackgroundResource(R.drawable.bg_bolinha_evento);
            bolinha.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#005792"))
            );

            TextView txt = new TextView(this);
            txt.setText(item);
            txt.setTypeface(fonte);
            txt.setTextSize(14f);
            txt.setTextColor(Color.parseColor("#444444"));
            txt.setLineSpacing(0, 1.2f);

            linha.addView(bolinha);
            linha.addView(txt);
            layout.addView(linha);
        }
    }

    private void popularCardapioMock() {
        cardapioMock.put(0, criarRefeicoes(
                Arrays.asList("Pão francês com manteiga", "Leite com achocolatado", "Fruta da estação"),
                Arrays.asList("Arroz branco", "Feijão carioca", "Frango grelhado", "Salada de alface e tomate", "Suco de laranja"),
                Arrays.asList("Bolo de cenoura", "Suco de goiaba")
        ));
        cardapioMock.put(1, criarRefeicoes(
                Arrays.asList("Mingau de aveia", "Suco de mamão", "Biscoito integral"),
                Arrays.asList("Arroz integral", "Lentilha", "Carne assada", "Couve refogada", "Agua de coco"),
                Arrays.asList("Iogurte com granola", "Banana")
        ));
        cardapioMock.put(2, criarRefeicoes(
                Arrays.asList("Tapioca com queijo", "Leite com café", "Mamão"),
                Arrays.asList("Macarrão ao sugo", "Frango à milanesa", "Salada de beterraba", "Suco de uva"),
                Arrays.asList("Pão de queijo", "Suco de abacaxi")
        ));
        cardapioMock.put(3, criarRefeicoes(
                Arrays.asList("Cuscuz com ovo", "Vitamina de banana", "Fruta da estação"),
                Arrays.asList("Arroz branco", "Feijão preto", "Peixe ao forno", "Salada de cenoura", "Suco de limão"),
                Arrays.asList("Bolo de milho", "Suco de maracujá")
        ));
        cardapioMock.put(4, criarRefeicoes(
                Arrays.asList("Pão com requeijão", "Achocolatado", "Maçã"),
                Arrays.asList("Arroz com brócolis", "Feijão carioca", "Bife acebolado", "Salada verde", "Suco de abacaxi"),
                Arrays.asList("Pipoca", "Suco de manga")
        ));
    }

    private Map<String, List<String>> criarRefeicoes(List<String> cafe, List<String> almoco, List<String> lanche) {
        Map<String, List<String>> map = new HashMap<>();
        map.put("cafe",   cafe);
        map.put("almoco", almoco);
        map.put("lanche", lanche);
        return map;
    }

    private int dpParaPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
