package com.example.myapplication.model;

import com.google.gson.annotations.SerializedName;

// ── Request: redefinir senha (e-mail + código + nova_senha) ───────────────
// Usado em: NovaSenha → POST /api/senha/redefinir
public class RedefinirSenhaRequest {
    private String email;
    private String codigo;

    @SerializedName("nova_senha")
    private String novaSenha;

    public RedefinirSenhaRequest(String email, String codigo, String novaSenha) {
        this.email     = email;
        this.codigo    = codigo;
        this.novaSenha = novaSenha;
    }

    public String getEmail()     { return email; }
    public String getCodigo()    { return codigo; }
    public String getNovaSenha() { return novaSenha; }
}