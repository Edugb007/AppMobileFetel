package com.example.myapplication;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CalendarioActivity extends AppCompatActivity {

    ImageButton btnVoltar, btnMesAnterior, btnProximoMes;
    TextView txtMesAno;
    GridLayout gridCalendario;
    RecyclerView recyclerEventos;
    EventosAdapter adapter;

    Calendar calAtual = Calendar.getInstance();

    // Mapa de todos os eventos: chave = "ano-mes" (ex: "2026-4" para Maio/2026)
    // Calendar.MONTH é 0-based: Janeiro=0, ..., Dezembro=11
    Map<String, List<Evento>> todosEventos = new HashMap<>();

    // Dias com evento no mês atual (atualizado dinamicamente)
    Set<Integer> diasComEvento = new HashSet<>();

    String[] nomesMeses = {"Janeiro","Fevereiro","Março","Abril","Maio","Junho",
            "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"};

    private static final int CELL_SIZE_DP = 44;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);

        btnVoltar       = findViewById(R.id.btnVoltarCalendario);
        btnMesAnterior  = findViewById(R.id.btnMesAnterior);
        btnProximoMes   = findViewById(R.id.btnProximoMes);
        txtMesAno       = findViewById(R.id.txtMesAno);
        gridCalendario  = findViewById(R.id.gridCalendario);
        recyclerEventos = findViewById(R.id.recyclerEventos);

        btnVoltar.setOnClickListener(v -> finish());

        btnMesAnterior.setOnClickListener(v -> {
            calAtual.add(Calendar.MONTH, -1);
            atualizarCalendario();
        });

        btnProximoMes.setOnClickListener(v -> {
            calAtual.add(Calendar.MONTH, 1);
            atualizarCalendario();
        });

        recyclerEventos.setLayoutManager(new LinearLayoutManager(this));
        // Adapter começa vazio; é atualizado junto com o calendário
        adapter = new EventosAdapter(this, new ArrayList<>());
        recyclerEventos.setAdapter(adapter);

        carregarTodosEventos();
        atualizarCalendario();
    }

    /**
     * Registra todos os eventos do calendário escolar.
     * A chave do mapa é "ano-mes" onde mes é 0-based (igual ao Calendar).
     */
    private void carregarTodosEventos() {
        // ── Março 2026 (mês 2) ──────────────────────────
        adicionarEvento(2026, 2, new Evento(
                "Feira de Ciências",
                "Apresentação de projetos no ginásio",
                12, "MAR", "Evento",
                ContextCompat.getColor(this, R.color.brand_primary)));
        adicionarEvento(2026, 2, new Evento(
                "Conselho de Classe",
                "Reunião dos professores — sem aula no período",
                20, "MAR", "Institucional",
                Color.parseColor("#E67E22")));

        // ── Abril 2026 (mês 3) ──────────────────────────
        adicionarEvento(2026, 3, new Evento(
                "Paixão de Cristo",
                "Feriado nacional — não haverá aulas",
                3, "ABR", "Feriado",
                Color.parseColor("#27AE60")));
        adicionarEvento(2026, 3, new Evento(
                "Domingo de Páscoa",
                "Feriado nacional — não haverá aulas",
                5, "ABR", "Feriado",
                Color.parseColor("#8E44AD")));
        adicionarEvento(2026, 3, new Evento(
                "Tiradentes",
                "Feriado nacional — não haverá aulas",
                21, "ABR", "Feriado",
                Color.parseColor("#27AE60")));

        // ── Maio 2026 (mês 4) ───────────────────────────
        adicionarEvento(2026, 4, new Evento(
                "Dia do Trabalho",
                "Feriado nacional — não haverá aulas",
                1, "MAI", "Feriado",
                Color.parseColor("#27AE60")));
        adicionarEvento(2026, 4, new Evento(
                "Semana da Tecnologia",
                "Exposição de projetos de TI e robótica",
                15, "MAI", "Evento",
                ContextCompat.getColor(this, R.color.brand_primary)));

        // ── Junho 2026 (mês 5) ──────────────────────────
        adicionarEvento(2026, 5, new Evento(
                "Corpus Christi",
                "Feriado nacional — não haverá aulas",
                4, "JUN", "Feriado",
                Color.parseColor("#27AE60")));
        adicionarEvento(2026, 5, new Evento(
                "Festa Junina",
                "Comemoração no pátio da escola",
                13, "JUN", "Evento",
                Color.parseColor("#E67E22")));
    }

    private void adicionarEvento(int ano, int mes, Evento evento) {
        String chave = ano + "-" + mes;
        if (!todosEventos.containsKey(chave)) {
            todosEventos.put(chave, new ArrayList<>());
        }
        todosEventos.get(chave).add(evento);
    }

    private void atualizarCalendario() {
        int mes = calAtual.get(Calendar.MONTH);
        int ano = calAtual.get(Calendar.YEAR);

        txtMesAno.setText(nomesMeses[mes] + " " + ano);

        // Pega eventos do mês/ano atual
        String chave = ano + "-" + mes;
        List<Evento> eventosMes = todosEventos.containsKey(chave)
                ? todosEventos.get(chave)
                : new ArrayList<>();

        // Atualiza dias com evento para marcação no grid
        diasComEvento.clear();
        for (Evento e : eventosMes) {
            diasComEvento.add(e.getDia());
        }

        // Atualiza a lista de eventos
        adapter = new EventosAdapter(this, eventosMes);
        recyclerEventos.setAdapter(adapter);

        // Monta o grid
        Calendar cal = Calendar.getInstance();
        cal.set(ano, mes, 1);
        int primeiroDiaSemana = cal.get(Calendar.DAY_OF_WEEK) - 1;
        int totalDias = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        Calendar hoje = Calendar.getInstance();
        int diaHoje = (hoje.get(Calendar.MONTH) == mes && hoje.get(Calendar.YEAR) == ano)
                ? hoje.get(Calendar.DAY_OF_MONTH) : -1;

        gridCalendario.removeAllViews();

        for (int i = 0; i < primeiroDiaSemana; i++) {
            gridCalendario.addView(criarCelulaVazia());
        }

        for (int dia = 1; dia <= totalDias; dia++) {
            gridCalendario.addView(criarCelulaDia(dia, dia == diaHoje, diasComEvento.contains(dia)));
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private View criarCelulaVazia() {
        View v = new View(this);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width  = 0;
        params.height = dpToPx(CELL_SIZE_DP);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        v.setLayoutParams(params);
        return v;
    }

    private View criarCelulaDia(int dia, boolean ehHoje, boolean temEvento) {
        TextView tv = new TextView(this);
        tv.setText(String.valueOf(dia));
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(14f);

        int sizePx  = dpToPx(CELL_SIZE_DP);
        int innerPx = dpToPx(36);

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width  = 0;
        params.height = sizePx;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        tv.setLayoutParams(params);

        if (ehHoje) {
            tv.setBackgroundResource(R.drawable.bg_dia_hoje);
            tv.setTextColor(Color.WHITE);
            tv.setTypeface(null, Typeface.BOLD);
            tv.setTextSize(15f);
            int pad = (sizePx - innerPx) / 2;
            tv.setPadding(pad, pad, pad, pad);
        } else if (temEvento) {
            tv.setBackgroundResource(R.drawable.bg_dia_evento);
            tv.setTextColor(ContextCompat.getColor(this, R.color.brand_primary));
            tv.setTypeface(null, Typeface.BOLD);
            int pad = (sizePx - innerPx) / 2;
            tv.setPadding(pad, pad, pad, pad);
        } else {
            // Usa a cor semântica do tema (claro/escuro)
            tv.setTextColor(ContextCompat.getColor(this, R.color.cal_dia_normal));
        }

        return tv;
    }
}
