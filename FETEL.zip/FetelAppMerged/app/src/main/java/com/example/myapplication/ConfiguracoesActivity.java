package com.example.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class ConfiguracoesActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "fetel_prefs";
    private static final String KEY_TEMA_ESCURO = "tema_escuro";

    Switch switchTema;
    LinearLayout itemIdioma, itemSobre, itemSair;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracoes);

        switchTema = findViewById(R.id.switchTema);
        itemIdioma = findViewById(R.id.itemIdioma);
        itemSobre  = findViewById(R.id.itemSobre);
        itemSair   = findViewById(R.id.itemSairConfig);

        // ── Volta ───────────────────────────────────────
        findViewById(R.id.btnVoltarConfig).setOnClickListener(v -> finish());

        // ── Tema: reflete a preferência salva ───────────
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean temaEscuroSalvo = prefs.getBoolean(KEY_TEMA_ESCURO, false);
        switchTema.setChecked(temaEscuroSalvo);

        switchTema.setOnCheckedChangeListener((btn, isChecked) -> {
            // Salva a preferência persistentemente
            prefs.edit().putBoolean(KEY_TEMA_ESCURO, isChecked).apply();

            // Aplica o tema imediatamente
            AppCompatDelegate.setDefaultNightMode(
                    isChecked
                            ? AppCompatDelegate.MODE_NIGHT_YES
                            : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        // ── Idioma (stub) ────────────────────────────────
        itemIdioma.setOnClickListener(v ->
                Toast.makeText(this, "Idioma — em breve!", Toast.LENGTH_SHORT).show()
        );

        // ── Sobre o app ──────────────────────────────────
        itemSobre.setOnClickListener(v -> abrirDialogSobre());

        // ── Logout ───────────────────────────────────────
        itemSair.setOnClickListener(v -> {
            Intent intent = new Intent(this, TelaLogin.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void abrirDialogSobre() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_sobre);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.88f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        dialog.findViewById(R.id.btnFecharSobre).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    /**
     * Chame este método em cada Activity (no onCreate, antes do setContentView)
     * para aplicar o tema salvo ao iniciar o app.
     * Exemplo: TelaCarregamento.onCreate -> AppThemeHelper.aplicarTema(this)
     */
    public static void aplicarTemaSalvo(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean temaEscuro = prefs.getBoolean(KEY_TEMA_ESCURO, false);
        AppCompatDelegate.setDefaultNightMode(
                temaEscuro
                        ? AppCompatDelegate.MODE_NIGHT_YES
                        : AppCompatDelegate.MODE_NIGHT_NO
        );
    }
}
