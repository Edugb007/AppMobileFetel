package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class NoticiasActivity extends AppCompatActivity {

    RecyclerView recyclerNoticias;
    ArrayList<Noticia> listaNoticias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticias);

        recyclerNoticias = findViewById(R.id.recyclerNoticias);
        listaNoticias    = new ArrayList<>();

        listaNoticias.add(new Noticia(
                "Feira de Ciências 2026",
                "Alunos apresentam projetos tecnológicos inovadores no ginásio.",
                "A Feira de Ciências deste ano promete ser a maior da história da escola. " +
                "Os alunos dos cursos técnicos de Informática, Eletrônica e Administração " +
                "apresentarão projetos desenvolvidos ao longo do semestre.\n\n" +
                "O evento acontecerá no ginásio principal, com entrada gratuita para toda " +
                "a comunidade. Serão premiados os três melhores projetos de cada área.\n\n" +
                "Não perca! Dias 18 e 19 de março, das 8h às 17h.",
                "08/03/2026", "Evento", R.drawable.img_feiras_ciencias
        ));

        listaNoticias.add(new Noticia(
                "Calendário de Provas — 1º Semestre",
                "Confira as datas das avaliações bimestrais de todas as turmas.",
                "A coordenação pedagógica divulgou o calendário completo de provas " +
                "do primeiro semestre letivo de 2026.\n\n" +
                "As avaliações bimestrais começam na segunda quinzena de março. " +
                "Alunos com pendências do semestre anterior devem procurar a secretaria " +
                "para regularizar a situação antes do início das provas.\n\n" +
                "O calendário completo está disponível no mural da escola e no site institucional.",
                "19/04/2026", "Aviso", R.drawable.img_calendario_provas
        ));

        listaNoticias.add(new Noticia(
                "Semana da Tecnologia",
                "Palestras, workshops e hackathon para alunos de todos os cursos.",
                "A FETEL realizará mais uma edição da Semana da Tecnologia, evento " +
                "que reúne estudantes, professores e profissionais do mercado.\n\n" +
                "A programação inclui palestras com especialistas, workshops práticos " +
                "de programação, design e robótica, além de um hackathon de 12 horas " +
                "com premiação para as melhores equipes.\n\n" +
                "As inscrições são gratuitas e podem ser feitas na secretaria da escola.",
                "11/05/2026", "Escola", R.drawable.img_semana_tec
        ));

        listaNoticias.add(new Noticia(
                "Processo Seletivo — Monitoria 2026",
                "Alunos do 2º e 3º ano podem se candidatar a vagas de monitor.",
                "A escola abre inscrições para o programa de monitoria do primeiro semestre. " +
                "Os monitores auxiliarão professores em disciplinas técnicas e receberão " +
                "certificação de horas complementares.\n\n" +
                "Requisitos: estar matriculado no 2º ou 3º ano, ter média acima de 7,0 " +
                "na disciplina pretendida e não ter reprovação no histórico.\n\n" +
                "Inscrições até 25 de Maio na secretaria ou pelo e-mail da coordenação.",
                "15/05/2026", "Oportunidade", R.drawable.img_processo_seletivo
        ));

        listaNoticias.add(new Noticia(
                "Manutenção do Laboratório de Informática",
                "Labs 2 e 3 ficarão indisponíveis entre os dias 22 e 24 de Maio.",
                "A equipe de TI realizará manutenção preventiva nos laboratórios 2 e 3 " +
                "durante o final da próxima semana.\n\n" +
                "Professores com aulas alocadas nesses laboratórios foram avisados e " +
                "terão suas turmas realocadas temporariamente para o laboratório 1.\n\n" +
                "O serviço inclui atualização de sistemas, substituição de equipamentos " +
                "e revisão da infraestrutura de rede.",
                "18/05/2026", "Aviso", R.drawable.img_manutencao_lab
        ));

        listaNoticias.add(new Noticia(
                "Visita Técnica — Empresa de Tecnologia",
                "Turmas de Informática visitarão empresa parceira em São Paulo.",
                "As turmas do 3º ano do curso Técnico em Informática realizarão visita " +
                "técnica a uma empresa de tecnologia parceira localizada na Paulista.\n\n" +
                "A visita inclui tour pelas instalações e roda de conversa com " +
                "profissionais formados pela FETEL.\n\n" +
                "Saída às 7h30 da escola. Autorização deve ser entregue até dia 30.",
                "24/05/2026", "Escola", R.drawable.img_visita_tecnica
        ));

        listaNoticias.add(new Noticia(
                "Programa de Estágio — Inscrições Abertas",
                "Empresas parceiras oferecem vagas para alunos do 3º ano.",
                "O setor de estágios divulga novas vagas disponibilizadas por empresas " +
                "parceiras para o primeiro semestre de 2026.\n\n" +
                "As vagas são voltadas para alunos do último ano dos cursos de " +
                "Informática, Administração e Contabilidade.\n\n" +
                "As entrevistas serão realizadas na própria escola nos dias 28 e 29 de Junho.",
                "04/06/2026", "Oportunidade", R.drawable.img_estagio
        ));

        listaNoticias.add(new Noticia(
                "Grêmio Estudantil — Eleições 2026",
                "Votação acontece na última semana de março no pátio central.",
                "O processo eleitoral do Grêmio Estudantil está em andamento. " +
                "A votação acontecerá nos dias 27 e 28 de Junho, das 8h às 17h.\n\n" +
                "Todos os alunos matriculados têm direito a voto. Basta apresentar " +
                "a carteirinha estudantil ou qualquer documento com foto.\n\n" +
                "O grêmio representa os estudantes junto à direção e organiza " +
                "eventos culturais e esportivos ao longo do ano.",
                "20/06/2026", "Escola", R.drawable.img_gremio
        ));

        recyclerNoticias.setLayoutManager(new LinearLayoutManager(this));
        recyclerNoticias.setAdapter(new NoticiasAdapter(this, listaNoticias));

        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());
    }
}
