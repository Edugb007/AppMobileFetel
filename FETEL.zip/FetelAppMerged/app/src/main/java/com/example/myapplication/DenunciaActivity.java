package com.example.myapplication;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DenunciaActivity extends AppCompatActivity {

    Spinner spinnerTipo;
    EditText editDescricao;
    TextView btnEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ConfiguracoesActivity.aplicarTemaSalvo(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_denuncia);

        spinnerTipo    = findViewById(R.id.spinnerTipoDenuncia);
        editDescricao  = findViewById(R.id.editDescricaoDenuncia);
        btnEnviar      = findViewById(R.id.btnEnviarDenuncia);

        // ── Voltar ─────────────────────────────────────
        findViewById(R.id.btnVoltarDenuncia).setOnClickListener(v -> finish());

        // ── Tipos de denúncia ──────────────────────────
        String[] tipos = {
                "Selecione o tipo...",
                "Bullying",
                "Cyberbullying",
                "Assédio",
                "Violência física",
                "Discriminação",
                "Uso de substâncias",
                "Vandalismo",
                "Outro"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, tipos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTipo.setAdapter(adapter);

        // ── Enviar ─────────────────────────────────────
        btnEnviar.setOnClickListener(v -> {
            int tipoPos = spinnerTipo.getSelectedItemPosition();
            String descricao = editDescricao.getText().toString().trim();

            if (tipoPos == 0) {
                Toast.makeText(this, "Selecione o tipo de denúncia.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (descricao.isEmpty()) {
                editDescricao.setError("Descreva o ocorrido.");
                editDescricao.requestFocus();
                return;
            }
            if (descricao.length() < 20) {
                editDescricao.setError("Descrição muito curta. Forneça mais detalhes.");
                editDescricao.requestFocus();
                return;
            }

            // TODO: enviar para backend (POST /denuncias)
            // { "tipo": tipos[tipoPos], "descricao": descricao }
            abrirDialogSucesso();
        });
    }

    private void abrirDialogSucesso() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_denuncia_sucesso);
        dialog.setCancelable(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog_rounded);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.88f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        dialog.findViewById(R.id.btnOkDenuncia).setOnClickListener(v -> {
            dialog.dismiss();
            spinnerTipo.setSelection(0);
            editDescricao.setText("");
            finish();
        });

        dialog.show();
    }
}
