package com.example.myapplication.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

/** Resposta do endpoint GET /api/aluno/boletim */
public class BoletimResponse {

    private boolean ok;
    private String  message;

    @SerializedName("aluno_id")
    private int alunoId;

    private List<Disciplina> disciplinas;

    public boolean isOk()                        { return ok; }
    public String  getMessage()                   { return message; }
    public int     getAlunoId()                   { return alunoId; }
    public List<Disciplina> getDisciplinas()      { return disciplinas; }
}