package com.example.myapplication.model;

// ── Request: verificar código (e-mail + código) ────────────────────────────
// Usado em: TelaCodigoRecup → POST /api/senha/verificar
public class VerificarCodigoRequest {
    private String email;
    private String codigo;

    public VerificarCodigoRequest(String email, String codigo) {
        this.email  = email;
        this.codigo = codigo;
    }

    public String getEmail()  { return email; }
    public String getCodigo() { return codigo; }
}