-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 14/05/2026 às 19:50
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tcc_etec`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `alunos`
--

CREATE TABLE `alunos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `matricula` varchar(64) DEFAULT NULL,
  `curso_id` int(11) DEFAULT NULL,
  `ano` smallint(6) DEFAULT NULL,
  `turma` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `alunos`
--

INSERT INTO `alunos` (`id`, `usuario_id`, `matricula`, `curso_id`, `ano`, `turma`) VALUES
(1, 5, '20260001', NULL, 1, 'A');

-- --------------------------------------------------------

--
-- Estrutura para tabela `biblioteca_emprestimos`
--

CREATE TABLE `biblioteca_emprestimos` (
  `id` int(11) NOT NULL,
  `livro_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `emprestado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `vencimento_em` datetime NOT NULL,
  `devolvido_em` datetime DEFAULT NULL,
  `status` enum('emprestado','devolvido','atrasado') NOT NULL DEFAULT 'emprestado',
  `multa_centavos` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Acionadores `biblioteca_emprestimos`
--
DELIMITER $$
CREATE TRIGGER `tg_estoque_entrada` AFTER UPDATE ON `biblioteca_emprestimos` FOR EACH ROW BEGIN
    IF NEW.status = 'devolvido' AND OLD.status != 'devolvido' THEN
        UPDATE biblioteca_livros
        SET copias_disponiveis = copias_disponiveis + 1
        WHERE id = NEW.livro_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tg_estoque_saida` AFTER INSERT ON `biblioteca_emprestimos` FOR EACH ROW BEGIN
    UPDATE biblioteca_livros
    SET copias_disponiveis = copias_disponiveis - 1
    WHERE id = NEW.livro_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `biblioteca_livros`
--

CREATE TABLE `biblioteca_livros` (
  `id` int(11) NOT NULL,
  `isbn` varchar(32) DEFAULT NULL,
  `imagem_capa` varchar(255) DEFAULT NULL,
  `link_pdf` varchar(500) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `editora` varchar(255) DEFAULT NULL,
  `ano_publicacao` int(11) DEFAULT NULL,
  `copias_total` int(11) NOT NULL DEFAULT 1,
  `copias_disponiveis` int(11) NOT NULL DEFAULT 1,
  `descricao` text DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `biblioteca_livros_midias`
--

CREATE TABLE `biblioteca_livros_midias` (
  `id` int(11) NOT NULL,
  `livro_id` int(11) NOT NULL,
  `url_imagem` varchar(500) DEFAULT NULL,
  `url_link` varchar(500) DEFAULT NULL,
  `tipo` enum('imagem','link') DEFAULT 'imagem',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `codigo` varchar(32) DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `imagem` varchar(500) DEFAULT NULL,
  `categoria` varchar(100) DEFAULT NULL,
  `unidade` text DEFAULT NULL,
  `salario_medio` varchar(150) DEFAULT NULL,
  `grade_curricular` text DEFAULT NULL,
  `certificacao` varchar(255) DEFAULT NULL,
  `prerequisitos` text DEFAULT NULL,
  `duracao` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `descricao_completa` text DEFAULT NULL,
  `turno` varchar(100) DEFAULT NULL,
  `beneficios` text DEFAULT NULL,
  `disciplinas` text DEFAULT NULL,
  `mercado_trabalho` text DEFAULT NULL,
  `popularidade` int(11) DEFAULT 0,
  `inscricoes_abertas` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `cursos`
--

INSERT INTO `cursos` (`id`, `codigo`, `nome`, `descricao`, `criado_em`, `imagem`, `categoria`, `unidade`, `salario_medio`, `grade_curricular`, `certificacao`, `prerequisitos`, `duracao`, `status`, `descricao_completa`, `turno`, `beneficios`, `disciplinas`, `mercado_trabalho`, `popularidade`, `inscricoes_abertas`) VALUES
(1, 'DS', 'Desenvolvimento de Sistemas', 'Curso técnico de programação', '2026-05-14 13:32:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ativo', NULL, NULL, NULL, NULL, NULL, 0, 0),
(2, 'ADM', 'Administração', 'Curso técnico de administração', '2026-05-14 13:32:14', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ativo', NULL, NULL, NULL, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `faltas`
--

CREATE TABLE `faltas` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `turma_disciplina_id` int(11) NOT NULL,
  `total_faltas` int(11) NOT NULL DEFAULT 0,
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `faltas`
--

INSERT INTO `faltas` (`id`, `aluno_id`, `turma_disciplina_id`, `total_faltas`, `atualizado_em`) VALUES
(1, 1, 44, 4, '2026-05-14 16:44:35'),
(2, 1, 45, 2, '2026-05-14 16:44:35'),
(3, 1, 46, 1, '2026-05-14 16:44:35'),
(4, 1, 47, 0, '2026-05-14 16:44:35');

-- --------------------------------------------------------

--
-- Estrutura para tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `cargo` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `matriculas`
--

CREATE TABLE `matriculas` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `turma_id` int(11) NOT NULL,
  `matriculado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('ativo','suspenso','concluido','cancelado') NOT NULL DEFAULT 'ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `matriculas`
--

INSERT INTO `matriculas` (`id`, `aluno_id`, `turma_id`, `matriculado_em`, `status`) VALUES
(1, 1, 1, '2026-05-14 13:36:26', 'ativo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `notas`
--

CREATE TABLE `notas` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `turma_disciplina_id` int(11) NOT NULL,
  `bimestre` tinyint(4) NOT NULL CHECK (`bimestre` between 1 and 4),
  `nota` decimal(4,2) NOT NULL CHECK (`nota` between 0 and 10),
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `notas`
--

INSERT INTO `notas` (`id`, `aluno_id`, `turma_disciplina_id`, `bimestre`, `nota`, `criado_em`, `atualizado_em`) VALUES
(1, 1, 44, 1, 7.50, '2026-05-14 16:44:24', '2026-05-14 16:44:24'),
(2, 1, 45, 1, 8.50, '2026-05-14 16:44:24', '2026-05-14 16:44:24'),
(3, 1, 46, 1, 6.00, '2026-05-14 16:44:24', '2026-05-14 16:44:24'),
(4, 1, 47, 1, 7.00, '2026-05-14 16:44:24', '2026-05-14 16:44:24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `noticias`
--

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `conteudo` text NOT NULL,
  `imagem_capa` varchar(255) DEFAULT NULL,
  `status_carrossel` tinyint(1) NOT NULL DEFAULT 0,
  `autor_id` int(11) DEFAULT NULL,
  `publicado_em` datetime DEFAULT NULL,
  `publicado` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `codigo` char(6) NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `expira_em` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `codigo`, `usado`, `criado_em`, `expira_em`) VALUES
(1, 'admin@fetel.edu.br', '390828', 1, '2026-05-13 22:15:32', '2026-05-13 22:30:32'),
(2, 'admin@fetel.edu.br', '304529', 1, '2026-05-13 22:16:24', '2026-05-13 22:31:24'),
(3, 'admin@fetel.edu.br', '509839', 1, '2026-05-13 22:18:03', '2026-05-13 22:33:03'),
(4, 'admin@fetel.edu.br', '551803', 1, '2026-05-13 22:22:32', '2026-05-13 22:37:32'),
(5, 'admin@fetel.edu.br', '647790', 1, '2026-05-14 10:57:11', '2026-05-14 11:12:11'),
(6, 'admin@fetel.edu.br', '045382', 1, '2026-05-14 11:03:01', '2026-05-14 11:18:01'),
(7, 'admin@fetel.edu.br', '634520', 1, '2026-05-14 11:03:53', '2026-05-14 11:18:53'),
(8, 'admin@fetel.edu.br', '567646', 1, '2026-05-14 11:05:18', '2026-05-14 11:20:18'),
(9, 'admin@fetel.edu.br', '186449', 1, '2026-05-14 11:06:32', '2026-05-14 11:21:32'),
(10, 'admin@fetel.edu.br', '464292', 1, '2026-05-14 11:07:26', '2026-05-14 11:22:26'),
(11, 'admin@fetel.edu.br', '496914', 1, '2026-05-14 12:14:42', '2026-05-14 12:29:42'),
(12, 'admin@fetel.edu.br', '894265', 1, '2026-05-14 12:30:06', '2026-05-14 12:45:06'),
(13, 'admin@fetel.edu.br', '677764', 1, '2026-05-14 12:32:21', '2026-05-14 12:47:21'),
(14, 'mariagames099@gmail.com', '235005', 1, '2026-05-14 14:39:55', '2026-05-14 14:54:55'),
(15, 'mariagames099@gmail.com', '308356', 1, '2026-05-14 14:40:03', '2026-05-14 14:55:03');

-- --------------------------------------------------------

--
-- Estrutura para tabela `redefinicoes_senha`
--

CREATE TABLE `redefinicoes_senha` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expira_em` datetime NOT NULL,
  `utilizado` tinyint(1) NOT NULL DEFAULT 0,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `refresh_tokens`
--

CREATE TABLE `refresh_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `refresh_tokens`
--

INSERT INTO `refresh_tokens` (`id`, `usuario_id`, `token_hash`, `expires_at`, `revoked_at`, `ip`, `user_agent`, `created_at`) VALUES
(1, 1, '421ee53345211921ed5224ee3765186837407b35fb6e272716919f89720eba1a', '2026-05-20 21:17:05', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 21:17:05'),
(2, 1, 'c3a827a119c2384d7fb91c2d3d30535122ae375c949acdd7ddeec5cafef78511', '2026-05-20 21:19:20', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 21:19:20'),
(3, 1, 'e1f247fcc76df45db2eaee99050191dca07a15c6266461ae0d7bec57d53cd4a9', '2026-05-20 21:25:32', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 21:25:32'),
(4, 1, 'f2b2ca286ec36855f45e1bd1a15554cd60929e74ddce9263f2e281b7fb9683ad', '2026-05-20 21:25:43', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 21:25:43'),
(5, 1, '531773ad8539bf21884e451ec40c60e708d205dbfdb1c9c9d1c6b41e39dd41c9', '2026-05-20 21:33:37', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 21:33:37'),
(6, 1, '0a2e1080aa0dc73b7eaf4d22af9467452cac9b074ff5ebc420086f9df5b3e5b0', '2026-05-20 22:17:05', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 22:17:05'),
(7, 1, '9a2d99f6baa6c83911e06abf79b64cca5325cdc8abc116056efe6dd9ea89bc6a', '2026-05-20 22:28:22', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-13 22:28:22'),
(8, 1, '41b50efc246ce58a93e8b943cfaea7abd5d9ab63c8754cb85beaac4d1c4d0dba', '2026-05-21 10:19:20', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 10:19:20'),
(9, 1, '16f2e6129af683c9cb23b670380e119019405822ec5ed8751429710925e6d430', '2026-05-21 10:57:04', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 10:57:04'),
(10, 1, '4d1378b226c50b39c8b532dc2bfd370995ec0b2d4af8fdc899b3838fa18b1774', '2026-05-21 11:05:26', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 11:05:26'),
(11, 1, '8a9016849239808ff19a353c16cd3905cbc4b00e808bd6dfae39ac59e3800fb3', '2026-05-21 11:06:26', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 11:06:26'),
(12, 1, '610d52306ed8645038b98a4a35f3eb466ad536e61b9293dbc09da0a64bec2348', '2026-05-21 12:29:59', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 12:29:59'),
(13, 1, 'a6974cabe9d6f56fa86bb69bcda9bcec825b5998fff644cea33ed9e5695e6e53', '2026-05-21 12:32:09', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 12:32:09'),
(14, 1, 'a952218ca17acc56f42b88b89d9b89c030e8b508eb2685d23f6a769e2b873713', '2026-05-21 12:33:03', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 12:33:03'),
(15, 1, '996ed4c514f79e3ade9ef8e6b3cfdb2ea3b424f89003e72e6ebe273cfd4e2335', '2026-05-21 14:37:56', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 14:37:56'),
(16, 5, '4324443a621a372fd996045c8a4e895cb62d6948eaf4a03266c0c4f6d23a01f2', '2026-05-21 14:41:35', NULL, '192.168.15.8', 'okhttp/3.14.9', '2026-05-14 14:41:35');

-- --------------------------------------------------------

--
-- Estrutura para tabela `registro_auditoria`
--

CREATE TABLE `registro_auditoria` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `acao` varchar(191) NOT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `registro_auditoria`
--

INSERT INTO `registro_auditoria` (`id`, `usuario_id`, `acao`, `meta`, `criado_em`) VALUES
(1, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 18:08:34'),
(2, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 19:05:54'),
(3, 5, 'login_realizado', '{\"user_id\":5,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"aluno\"}', '2026-05-13 19:14:57'),
(4, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 19:15:01'),
(5, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"192.168.15.8\",\"user_agent\":\"Mozilla\\/5.0 (Linux; Android 10; K) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/148.0.0.0 Mobile Safari\\/537.36\",\"perfil\":\"admin\"}', '2026-05-13 19:37:35'),
(6, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 19:42:30'),
(7, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 20:41:33'),
(8, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-13 21:13:39'),
(9, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-14 10:15:21'),
(10, 1, 'login_realizado', '{\"user_id\":1,\"ip\":\"::1\",\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36 OPR\\/131.0.0.0\",\"perfil\":\"admin\"}', '2026-05-14 12:31:26');

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes_secretaria`
--

CREATE TABLE `solicitacoes_secretaria` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `tipo_solicitacao` varchar(64) NOT NULL,
  `detalhes` text DEFAULT NULL,
  `status` enum('aberto','em_andamento','encerrado','rejeitado') NOT NULL DEFAULT 'aberto',
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tentativas_login`
--

CREATE TABLE `tentativas_login` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data` date NOT NULL,
  `tentativas` int(11) NOT NULL DEFAULT 0,
  `ultimo_tentativa` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `turmas`
--

CREATE TABLE `turmas` (
  `id` int(11) NOT NULL,
  `curso_id` int(11) DEFAULT NULL,
  `nome` varchar(128) NOT NULL,
  `ano` smallint(6) DEFAULT NULL,
  `periodo` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `turmas`
--

INSERT INTO `turmas` (`id`, `curso_id`, `nome`, `ano`, `periodo`) VALUES
(1, 1, '3º DS A', 2026, 'Manhã');

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma_disciplinas`
--

CREATE TABLE `turma_disciplinas` (
  `id` int(11) NOT NULL,
  `turma_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `professor` varchar(120) DEFAULT NULL,
  `carga_horaria` int(11) DEFAULT 80,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `turma_disciplinas`
--

INSERT INTO `turma_disciplinas` (`id`, `turma_id`, `nome`, `professor`, `carga_horaria`, `criado_em`) VALUES
(44, 1, 'Matemática', 'Prof. Carlos', 80, '2026-05-14 16:36:10'),
(45, 1, 'Português', 'Profa. Ana', 80, '2026-05-14 16:36:10'),
(46, 1, 'Física', 'Prof. Roberto', 60, '2026-05-14 16:36:10'),
(47, 1, 'Química', 'Profa. Juliana', 60, '2026-05-14 16:36:10'),
(48, 1, 'História', 'Profa. Beatriz', 60, '2026-05-14 16:36:10'),
(49, 1, 'Geografia', 'Prof. Marcos', 60, '2026-05-14 16:36:10'),
(50, 1, 'Inglês', 'Profa. Sandra', 40, '2026-05-14 16:36:10'),
(51, 1, 'Educação Física', 'Prof. Rafael', 40, '2026-05-14 16:36:10');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha_hash` varchar(255) DEFAULT NULL,
  `nome_completo` varchar(255) DEFAULT NULL,
  `papel` enum('aluno','funcionario','admin') NOT NULL DEFAULT 'aluno',
  `telefone` varchar(32) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `ativo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `senha_hash`, `nome_completo`, `papel`, `telefone`, `criado_em`, `atualizado_em`, `ativo`) VALUES
(1, 'admin@fetel.edu.br', '$2y$12$XmvKXYhWdNVnv24o6TGZLekWpl7x5XcACowk3uWXc.o49GWxfUIji', 'Administrador', 'admin', NULL, '2026-01-08 10:59:21', '2026-04-21 21:58:45', 1),
(5, 'mariagames099@gmail.com', '$2y$12$jd65HgAapxKqk6tDu.ga7ugKGLpdTjFlzy2kF6CrQxuSeI9EsKZcS', 'Eduardo do Nascimento Oliveira', 'aluno', '11970555679', '2026-01-08 13:40:17', '2026-04-26 15:11:19', 1),
(6, 'dnascimentomorato@gmail.com', '$2y$12$HxiL2fUqr0iaZjfEio.n9uDgW6K4FZL.f1pmU12Z.9rSns37eAjkm', 'Eduardo N. Oliveira', 'admin', NULL, '2026-01-13 11:30:40', '2026-03-15 21:10:42', 1),
(8, 'testedeveloper07@gmail.com', '$2y$12$ucIm13.HAdmUar8KfZ6pxO/x4X1PAh0phUkrh3NzDqxyxVn2UlWye', 'Eduardo Oliveira Macedo', 'aluno', NULL, '2026-03-01 21:00:52', '2026-03-15 23:14:57', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vestibular_inscricoes`
--

CREATE TABLE `vestibular_inscricoes` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `curso` varchar(100) NOT NULL,
  `turno` varchar(50) NOT NULL,
  `modalidade` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `curso_id` (`curso_id`);

--
-- Índices de tabela `biblioteca_emprestimos`
--
ALTER TABLE `biblioteca_emprestimos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `livro_id` (`livro_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `biblioteca_livros`
--
ALTER TABLE `biblioteca_livros`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `biblioteca_livros_midias`
--
ALTER TABLE `biblioteca_livros_midias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `livro_id` (`livro_id`);

--
-- Índices de tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `faltas`
--
ALTER TABLE `faltas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_falta` (`aluno_id`,`turma_disciplina_id`),
  ADD KEY `turma_disciplina_id` (`turma_disciplina_id`);

--
-- Índices de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `matriculas`
--
ALTER TABLE `matriculas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `aluno_id` (`aluno_id`),
  ADD KEY `turma_id` (`turma_id`);

--
-- Índices de tabela `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_nota` (`aluno_id`,`turma_disciplina_id`,`bimestre`),
  ADD KEY `turma_disciplina_id` (`turma_disciplina_id`);

--
-- Índices de tabela `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `autor_id` (`autor_id`);

--
-- Índices de tabela `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_codigo` (`codigo`);

--
-- Índices de tabela `redefinicoes_senha`
--
ALTER TABLE `redefinicoes_senha`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `refresh_tokens`
--
ALTER TABLE `refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `indice_usuario_id` (`usuario_id`);

--
-- Índices de tabela `registro_auditoria`
--
ALTER TABLE `registro_auditoria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `solicitacoes_secretaria`
--
ALTER TABLE `solicitacoes_secretaria`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `tentativas_login`
--
ALTER TABLE `tentativas_login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `turmas`
--
ALTER TABLE `turmas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `curso_id` (`curso_id`);

--
-- Índices de tabela `turma_disciplinas`
--
ALTER TABLE `turma_disciplinas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `turma_id` (`turma_id`,`nome`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `vestibular_inscricoes`
--
ALTER TABLE `vestibular_inscricoes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alunos`
--
ALTER TABLE `alunos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `biblioteca_emprestimos`
--
ALTER TABLE `biblioteca_emprestimos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `biblioteca_livros`
--
ALTER TABLE `biblioteca_livros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `biblioteca_livros_midias`
--
ALTER TABLE `biblioteca_livros_midias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `faltas`
--
ALTER TABLE `faltas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `matriculas`
--
ALTER TABLE `matriculas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `notas`
--
ALTER TABLE `notas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `redefinicoes_senha`
--
ALTER TABLE `redefinicoes_senha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `refresh_tokens`
--
ALTER TABLE `refresh_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `registro_auditoria`
--
ALTER TABLE `registro_auditoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `solicitacoes_secretaria`
--
ALTER TABLE `solicitacoes_secretaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tentativas_login`
--
ALTER TABLE `tentativas_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `turmas`
--
ALTER TABLE `turmas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `turma_disciplinas`
--
ALTER TABLE `turma_disciplinas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `vestibular_inscricoes`
--
ALTER TABLE `vestibular_inscricoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `alunos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `alunos_ibfk_2` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`);

--
-- Restrições para tabelas `biblioteca_emprestimos`
--
ALTER TABLE `biblioteca_emprestimos`
  ADD CONSTRAINT `biblioteca_emprestimos_ibfk_1` FOREIGN KEY (`livro_id`) REFERENCES `biblioteca_livros` (`id`),
  ADD CONSTRAINT `biblioteca_emprestimos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `biblioteca_livros_midias`
--
ALTER TABLE `biblioteca_livros_midias`
  ADD CONSTRAINT `biblioteca_livros_midias_ibfk_1` FOREIGN KEY (`livro_id`) REFERENCES `biblioteca_livros` (`id`);

--
-- Restrições para tabelas `faltas`
--
ALTER TABLE `faltas`
  ADD CONSTRAINT `faltas_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `faltas_ibfk_2` FOREIGN KEY (`turma_disciplina_id`) REFERENCES `turma_disciplinas` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `funcionarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `matriculas`
--
ALTER TABLE `matriculas`
  ADD CONSTRAINT `matriculas_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `matriculas_ibfk_2` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`);

--
-- Restrições para tabelas `notas`
--
ALTER TABLE `notas`
  ADD CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notas_ibfk_2` FOREIGN KEY (`turma_disciplina_id`) REFERENCES `turma_disciplinas` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `noticias`
--
ALTER TABLE `noticias`
  ADD CONSTRAINT `noticias_ibfk_1` FOREIGN KEY (`autor_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `redefinicoes_senha`
--
ALTER TABLE `redefinicoes_senha`
  ADD CONSTRAINT `redefinicoes_senha_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `registro_auditoria`
--
ALTER TABLE `registro_auditoria`
  ADD CONSTRAINT `registro_auditoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `solicitacoes_secretaria`
--
ALTER TABLE `solicitacoes_secretaria`
  ADD CONSTRAINT `solicitacoes_secretaria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `tentativas_login`
--
ALTER TABLE `tentativas_login`
  ADD CONSTRAINT `tentativas_login_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `turmas`
--
ALTER TABLE `turmas`
  ADD CONSTRAINT `turmas_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`);

--
-- Restrições para tabelas `turma_disciplinas`
--
ALTER TABLE `turma_disciplinas`
  ADD CONSTRAINT `turma_disciplinas_ibfk_1` FOREIGN KEY (`turma_id`) REFERENCES `turmas` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
